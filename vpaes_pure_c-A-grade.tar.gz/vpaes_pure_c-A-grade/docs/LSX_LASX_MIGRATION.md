---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: 0ae1345594677cc4cb4f9b8542d022ed
    PropagateID: 0ae1345594677cc4cb4f9b8542d022ed
    ReservedCode1: 304502203675a2463de2d30b0375316c5303c398024de4884756fd895e3bfcc755496fe4022100f62c23d460b9edeb4efa41c43addd4433a93da632da6063ea64ce436f74b520b
    ReservedCode2: 3045022100aaa9a39c3a0a67bda19e247a9ade785677e7ef9448c68d29b95843418cad9e6102204371cad88ef713402b2beff8dca691ce95271ced42939baaf32e94c8fa1c97f5
---

# vpaes_pure_c → LoongArch LSX / LASX Migration Guide

> **Status: technical plan, no code changes.**
> This document describes how to port the existing scalar implementation
> (`src/vpaes.c`) onto LoongArch's 128-bit **LSX** and 256-bit **LASX**
> SIMD extensions, and onto the LA664-generation `xcrypt-e` / `xcrypt-d`
> hardware AES instructions.
>
> It is the **detailed migration companion** to `docs/PHASE3_SIMD_ANALYSIS.md`,
> which is the analytical baseline.  Here the focus is on:
> (a) a function-by-function mapping from scalar code to intrinsics,
> (b) the exact dispatch / runtime-detection scaffolding,
> (c) the data-format invariants that every port must preserve so the
>     existing 4156-vector KAT suite remains the contract,
> (d) the per-phase effort, risk, and projected throughput.
>
> Target audience: maintainers who have to actually write the SIMD code.
> All numbers assume a **LA664-class 4-issue out-of-order core** at
> **3.0 GHz** unless explicitly noted.

---

## Table of contents

1. [Background recap (what LoongArch gives us)](#1-background-recap)
2. [Current scalar surface area to be ported](#2-current-scalar-surface-area)
3. [Phase 3.A — SLP-vectorised LSX (128-bit, single block)](#3-phase-3a)
4. [Phase 3.B — Hamburg-style vpaes on LASX (256-bit, 2-block parallel)](#4-phase-3b)
5. [Phase 3.C — LA664 `xcrypt-e` / `xcrypt-d` hardware path](#5-phase-3c)
6. [Runtime detection (`getauxval`) and compile-time toggles](#6-runtime-detection)
7. [Dispatch integration into the existing `vpaes_ctx`](#7-dispatch-integration)
8. [Memory-alignment and ABI contracts](#8-memory-alignment)
9. [Register-pressure analysis](#9-register-pressure)
10. [Validation: keeping the 4156-vector KAT contract](#10-validation)
11. [Performance budget and headroom](#11-performance-budget)
12. [Risk register and known foot-guns](#12-risk-register)
13. [Effort / order of attack](#13-effort)
14. [Reference: instruction quick-lookup table](#14-reference)

---

## 1. Background recap <a name="1-background-recap"></a>

### 1.1 Register file

LoongArch64 provides **two** SIMD extensions backed by overlapping
physical storage:

| Extension | Width  | Registers | Mnemonic prefix | Intrinsic header  |
|-----------|-------:|-----------|-----------------|-------------------|
| **LSX**   | 128 b  | `v0`–`v31` | `v…`           | `<lsxintrin.h>`   |
| **LASX**  | 256 b  | `x0`–`x31` | `xv…`          | `<lasxintrin.h>`  |

`x0` and `v0` share the low 128 bits of the same physical register.
**LASX implies LSX** at compile time (`-mlasx` turns on `-mlsx`).

Important architectural quirk (different from x86 AVX):

> A 128-bit `v…` instruction issued on a 256-bit `xr` register operates
> on the **full 256 bits** (LSX on LASX is widened).
> This is **the opposite of x86** where 128-bit AVX ops zero the high lane.

Practical consequence: **when both blocks of a 2-block LASX routine
must be zeroed out** (e.g. partial-block CTR tail), a single `xvxor`
on the 256-bit register suffices; we never need the x86-style
`vzeroupper`-equivalent after a 128-bit op.

### 1.2 The key instruction: `vshuf.b` / `xvshuf.b`

```
vshuf.b  vd, vj, vk          ; vd[i] = (vk[i] & 0x80) ? 0 : vj[vk[i] & 0x0f]
xvshuf.b xd, xj, xk          ; same, per 128-bit lane
```

Semantics are byte-for-byte identical to Intel SSSE3 `pshufb` (and
to ARMv8 `tbl1`).  The high-bit-of-control-equals-zero rule is the
trick that turns a permute into a constant-time conditional select.

This is the **single instruction** on which vpaes was designed.

### 1.3 Other instructions we will use

| Operation                | LSX                    | LASX                | x86 equiv         |
|--------------------------|------------------------|---------------------|-------------------|
| 8-bit broadcast from GPR | `vreplgr2vr.b`         | `xvreplgr2vr.b`     | `pshufb + set1`   |
| 32-bit broadcast from GPR| `vreplgr2vr.w`         | `xvreplgr2vr.w`     | `movd + pshufd`   |
| Byte broadcast within reg| `vreplvei.b`           | `xvreplvei.b`       | `pshufb`          |
| 128 / 256-bit XOR        | `vxor.v`               | `xvxor.v`           | `pxor / vpxor`    |
| Bitwise AND / OR         | `vand.v` / `vor.v`     | `xvand.v` / `xvor.v`| `pand / vpand`    |
| Byte shift left / right  | `vslli.b` / `vsrli.b`  | `xvslli.b` / `xvsrli.b` | `psllw / vpsllw` |
| Byte addition (mod 256)  | `vadd.b`               | `xvadd.b`           | none (built-in)   |
| 128-bit load             | `vld` (16-byte aligned)| `xvld` (32-byte aligned) | `movdqa / vmovdqa` |
| 128-bit store            | `vst`                  | `xvst`              | `movdqa / vmovdqa`|

Compiler support: **GCC 13+** and **Clang 16+** provide full intrinsics.
Compile flags: `-mlsx` (LSX), `-mlasx` (LASX, implies LSX).

---

## 2. Current scalar surface area to be ported <a name="2-current-scalar-surface-area"></a>

The single source file `src/vpaes.c` (≈600 lines) breaks into the
following portable functions, each of which is a candidate replacement
target for the SIMD path:

| Symbol              | Where (line)         | Public? | SIMD replacement target                |
|---------------------|----------------------|---------|---------------------------------------|
| `vpaes_set_key`     | ~152                 | yes     | unchanged (key setup stays scalar)    |
| `set_key_impl`      | ~121                 | no      | unchanged                             |
| `inv_mix_columns_columns` | ~86             | no      | unchanged (1-time at `set_key`)       |
| `bytes_to_state`    | ~223                 | no      | **Phase 3.A+** 128-bit load + lane rearrange |
| `state_to_bytes`    | ~252                 | no      | **Phase 3.A+** lane rearrange + 128-bit store |
| `enc_round`         | ~284                 | no      | **Phase 3.A** SLP LSX or **3.B** vpermb |
| `dec_round`         | ~301                 | no      | **Phase 3.A** SLP LSX                |
| `enc_last`          | ~319                 | no      | **Phase 3.A** SLP LSX (SubBytes+ShiftRows fused via T0d..T3d) |
| `dec_last_core`     | ~340                 | no      | **Phase 3.A** SLP LSX                 |
| `enc_128/192/256`   | ~358 / ~373 / ~385   | no      | stays — dispatches specialised rounds |
| `dec_128/192/256`   | ~398 / ~419 / ~438   | no      | stays                                 |
| `vpaes_encrypt_block`| ~475                | yes     | stays as a thin wrapper               |
| `vpaes_decrypt_block`| ~487                | yes     | stays as a thin wrapper               |
| `vpaes_ecb_encrypt` | ~504                 | yes     | **Phase 3.B** outer 2-block unroll    |
| `vpaes_ecb_decrypt` | ~515                 | yes     | **Phase 3.B** outer 2-block unroll    |
| `vpaes_cbc_encrypt` | ~527                 | yes     | **Phase 3.B** CBC-enc 2-block (sequential IV dependency) |
| `vpaes_cbc_decrypt` | ~544                 | yes     | **Phase 3.B** CBC-dec 4-block parallel (no IV-dep) |
| `vpaes_ctr_xcrypt`  | ~569                 | yes     | **Phase 3.B** CTR 2-block parallel + tail mask |

**Constant data** (also portable today, kept verbatim by the SIMD path):

* `Te0..Te3` (4 × 1 KB) — encrypt T-tables
* `Td0..Td3` (4 × 1 KB) — decrypt T-tables
* `T0d..T3d` (4 × 256 B) — last-round encrypt
* `TD0d..TD3d` (4 × 256 B) — last-round decrypt
* `sbox[256]`, `Rcon[15]` — used only by `sub_word`/`rot_word`/key-setup

The total `.rodata` is **~8.5 KB today**; it shrinks to ~8 KB once the
vpaes-style perm tables of Phase 3.B replace `Te0..Te3`/`Td0..Td3`.

---

## 3. Phase 3.A — SLP-vectorised LSX (128-bit, single block) <a name="3-phase-3a"></a>

**Goal:** get to ~480 MB/s single-block enc on LA664 (≈ 2× the
current 275 MB/s) with **minimal disruption** to the test contract.
All current KAT vectors must remain bit-exact.

### 3.A.1 Strategy

**Keep** the `Te0..Te3` / `Td0..Td3` T-tables (no porting of tables
needed).  Replace **only** the inner bodies of `enc_round`, `dec_round`,
`enc_last`, `dec_last_core` with SLP-vectorised LSX intrinsics that
operate on a 128-bit register holding all 4 state words at once.

The state representation stays the same: `s[4]` is a 4-word column-major
array.  In the SIMD path, we **also** keep a 128-bit register `vs` that
holds the same 4 words packed as `(s0, s1, s2, s3)` (i.e.
`vs[127:96]=s0`, `vs[95:64]=s1`, `vs[63:32]=s2`, `vs[31:0]=s3`).

### 3.A.2 `enc_round` in 9 µops

```c
static inline __m128i enc_round_lsx(__m128i vs, const uint32_t *rk)
{
    /* Replicate the 4-byte look-up indices across 16 bytes so that
     * a single 128-bit load from each Te_k table gives us all 4
     * 32-bit partials simultaneously.                              */
    __m128i shuf_0 = _mm_set1_epi32(0x00000000);  /* always 0       */
    __m128i s0 = _mm_shuffle_epi32(vs, _MM_SHUFFLE(3,3,3,3)); /* s0 4× */
    __m128i s1 = _mm_shuffle_epi32(vs, _MM_SHUFFLE(2,2,2,2)); /* s1 4× */
    __m128i s2 = _mm_shuffle_epi32(vs, _MM_SHUFFLE(1,1,1,1)); /* s2 4× */
    __m128i s3 = _mm_shuffle_epi32(vs, _MM_SHUFFLE(0,0,0,0)); /* s3 4× */

    /* vshuf.b indices = (byte_lane<<0)|0  (no zeroing, no high-bit set) */
    __m128i idx0 = _mm_and_si128(s0, _mm_set1_epi32(0x000000ff));
    __m128i idx1 = _mm_and_si128(_mm_srli_epi32(s1,  8), _mm_set1_epi32(0x000000ff));
    __m128i idx2 = _mm_and_si128(_mm_srli_epi32(s2, 16), _mm_set1_epi32(0x000000ff));
    __m128i idx3 = _mm_and_si128(_mm_srli_epi32(s3, 24), _mm_set1_epi32(0x000000ff));

    /* 4 × 128-bit gathers from T-tables.
     * LSX lacks an indexed-gather; we use a vshuf.b against the
     * table base extended to 128 bits.  (Table base must be made
     * addressable as a 16-byte vector via __builtin_convertvector
     * or a small helper that emits a 128-bit MOVESI of the table
     * 32-bit entry — see §3.A.4 for the gather-pseudo-code.)      */
    __m128i t0 = lsx_gather32(Te0, idx0);  /* 4 × 32 b partials */
    __m128i t1 = lsx_gather32(Te1, idx1);
    __m128i t2 = lsx_gather32(Te2, idx2);
    __m128i t3 = lsx_gather32(Te3, idx3);

    __m128i rk_v = _mm_load_si128((const __m128i *)rk);
    __m128i acc = _mm_xor_si128(_mm_xor_si128(t0, t1),
                                _mm_xor_si128(t2, t3));
    return _mm_xor_si128(acc, rk_v);   /* 1 µop AddRoundKey */
}
```

**Latency budget on LA664** (4-issue OoO, 1 cy/µop):

| Step                              | µops | Notes                |
|-----------------------------------|-----:|----------------------|
| 4× `_mm_shuffle_epi32` (lane dup) |   4  | independent, 1 cy    |
| 4× `_mm_and_si128` + 2× `_mm_srli_epi32` | 6 | mostly independent |
| 4× `lsx_gather32`                |   4  | 4 independent L1 loads |
| 3× `_mm_xor_si128`               |   3  | 1 µop each, 128-bit |
| 1× `_mm_load_si128` rk           |   1  |                       |
| **Total**                         | **18 µops / round**  |      |
| **Cycles / block** (10 rounds)   |  ~45  | ≈ 0.94 c/B on 3 GHz |

Expected: **480 MB/s** AES-128 single-block enc (matches the
PHASE3_SIMD_ANALYSIS.md §5 estimate).

### 3.A.3 `enc_last` and `dec_last_core`

For the last round we keep the **T0d..T3d** (256 B each) tables but
use 16-bit OR to fuse them — same shape as today:

```c
static inline __m128i enc_last_lsx(__m128i vs, const uint32_t *rk)
{
    __m128i s0 = _mm_shuffle_epi32(vs, _MM_SHUFFLE(3,3,3,3));
    __m128i s1 = _mm_shuffle_epi32(vs, _MM_SHUFFLE(2,2,2,2));
    __m128i s2 = _mm_shuffle_epi32(vs, _MM_SHUFFLE(1,1,1,1));
    __m128i s3 = _mm_shuffle_epi32(vs, _MM_SHUFFLE(0,0,0,0));

    __m128i i0 = _mm_and_si128(                s0,  _mm_set1_epi32(0xff));
    __m128i i1 = _mm_and_si128(_mm_srli_epi32(s1,  8), _mm_set1_epi32(0xff));
    __m128i i2 = _mm_and_si128(_mm_srli_epi32(s2, 16), _mm_set1_epi32(0xff));
    __m128i i3 = _mm_and_si128(_mm_srli_epi32(s3, 24), _mm_set1_epi32(0xff));

    __m128i o0 = lsx_gather32(T0d, i0);   /* 4 × 32 b  (one byte each) */
    __m128i o1 = lsx_gather32(T1d, i1);
    __m128i o2 = lsx_gather32(T2d, i2);
    __m128i o3 = lsx_gather32(T3d, i3);

    __m128i acc = _mm_or_si128(_mm_or_si128(o0, o1),
                               _mm_or_si128(o2, o3));
    __m128i rk_v = _mm_load_si128((const __m128i *)rk);
    return _mm_xor_si128(acc, rk_v);
}
```

Note the **OR vs XOR** swap from `enc_round`: the last round skips
MixColumns, so byte k of the output column comes **only** from input
byte k of one column; T0d..T3d each return 32-bit words with a single
non-zero byte in slot k, and OR-ing them sets all 4 byte slots.

`dec_last_core` is the symmetric pattern using `TD0d..TD3d`.

### 3.A.4 The LSX "32-bit gather" — a small but crucial helper

LSX has **no native indexed gather** in the base ISA.  We need four
32-bit values, one from each of four distinct cache lines of the same
T-table, indexed by a per-lane byte.

The simplest portable solution that the compiler will not pessimise:

```c
/* Return a 128-bit register where lane k (k=0..3) is table[idx_byte[k]].
 * table must be 32-bit-aligned and at least 256*4 bytes.
 * idx must have each 32-bit lane equal to the desired byte index
 * replicated in the low 8 bits.                                        */
static inline __m128i lsx_gather32(const uint32_t *table, __m128i idx)
{
    /* Use a small lookup vector built at compile time:
     * we want to index 256 × 4-byte entries by a single byte.
     * Trick: a 16-byte vector can hold 4 such entries; for a
     * scatter-gather we use vshuf.b on a replicated 4 KB table
     * pointer in 4 parallel cache-line slices.
     * Implementation note: the only correct way in pure intrinsics
     * is to issue 4 explicit 32-bit scalar loads + a __m128i pack.   */
    uint32_t x[4];
    x[0] = table[_mm_cvtsi128_si32(idx)               & 0xff];
    x[1] = table[_mm_cvtsi128_si32(_mm_srli_si128(idx, 4)) & 0xff];
    x[2] = table[_mm_cvtsi128_si32(_mm_srli_si128(idx, 8)) & 0xff];
    x[3] = table[_mm_cvtsi128_si32(_mm_srli_si128(idx, 12))& 0xff];
    return _mm_loadu_si128((const __m128i *)x);
}
```

GCC/Clang at `-O2` will lower the four 32-bit loads + the pack into
the **same µops** as the explicit intrinsics — this helper exists for
**portability across compilers**, not because the intrinsics are slow.

### 3.A.5 Function-level migration checklist (Phase 3.A)

| # | Scalar function              | LSX replacement                       | Lines delta |
|---|------------------------------|---------------------------------------|------------:|
| 1 | `lsx_gather32`               | new helper (private)                  | +15         |
| 2 | `enc_round`                  | `enc_round_lsx`                       | +35 / -8    |
| 3 | `dec_round`                  | `dec_round_lsx`                       | +30 / -8    |
| 4 | `enc_last`                   | `enc_last_lsx`                        | +25 / -6    |
| 5 | `dec_last_core`              | `dec_last_core_lsx`                   | +25 / -6    |
| 6 | `enc_128/192/256`            | copy of `enc_128_lsx/...` (rounds unrolled, same loop) | +90 / -45 |
| 7 | `dec_128/192/256`            | similar                                | +90 / -60   |
| 8 | `vpaes_encrypt_block`        | + 1-line `bytes_to_state_lsx` preamble | +5 / -2     |
| 9 | `vpaes_decrypt_block`        | + 1-line `bytes_to_state_lsx` preamble | +5 / -2     |
|10 | dispatch binding (`enc_dispatch[]`) | new `enc_dispatch_lsx[]` indexed by rounds | +8  |
|11 | `vpaes_set_key`              | +1 line to bind LSX if `__loongarch_sx` | +3 / -1   |
|   | **Total delta**              |                                        | **~ +200 / -138** |

### 3.A.6 Validation gates for Phase 3.A

Each row must hold before the phase is declared complete:

| Gate | Pass criterion                                                                             |
|------|---------------------------------------------------------------------------------------------|
| G1   | `make check` with `-mlsx` passes 8/8 sanity tests                                          |
| G2   | `make kat-ECB && make kat-CBC` under `-mlsx` passes 48/48 files (4156/4156 vectors)         |
| G3   | `bench c` (single-block) ≥ **400 MB/s** on the sandbox host, ideally ≥ 480 MB/s             |
| G4   | `bench c` ECB ≥ **400 MB/s**                                                                |
| G5   | No new UBSan / ASan reports under `-fsanitize=address,undefined -mlsx`                     |
| G6   | Strict-warning build (`-Werror -Wstrict-aliasing=2 -Wcast-align -Wpedantic -mlsx`) clean    |

Gates G1 / G2 / G5 are **non-negotiable correctness**; G3 / G4 / G6 are
performance / hygiene.

---

## 4. Phase 3.B — Hamburg-style vpaes on LASX (256-bit, 2-block parallel) <a name="4-phase-3b"></a>

**Goal:** reach ~1 200 MB/s single-block, **~2 400 MB/s** ECB
(2-block unrolled) on LA664.  Same test contract as Phase 3.A.

### 4.B.1 Why this is faster

Each round becomes a sequence of **6 µops**:

```
# vr_in holds 16 bytes of (lane-low 128-bit block A) AND 16 bytes of
# (lane-high 128-bit block B).  Per-lane operations are independent.

vldi      vr_a, vps_round_lo          # 16 perm indices, lane-replicated
xvpermb   vr_a, xr_in, xr_a            # 1 µop, fully pipe-lined
xvxor.v   vr_a, xr_a, xr_k             # AddRoundKey on both blocks
vldi      vr_b, vps_round_hi
xvpermb   vr_b, xr_in, xr_b            # 1 µop
xvxor.v   xr_out, xr_a, xr_b           # combine: 2 blocks in parallel
```

That's **6 µops per round per 2 blocks** = 3 µops / block / round,
or **30 µops / 2 blocks** for AES-128 (10 rounds).
At 1 µop / cycle ⇒ **15 cycles for 2 blocks ⇒ 8 cycles / block
⇒ 600 MB/s / core / GHz** = 1.8 GB/s at 3 GHz single-threaded.

(With a 4-issue core the per-µop budget lets us overlap two rounds,
giving the **2.4 GB/s** projected in PHASE3_SIMD_ANALYSIS.md §5.)

### 4.B.2 The two new constant tables

We **replace** the 8 KB `Te0..Te3` / `Td0..Td3` with two new tables:

| Symbol           | Size   | Bytes per entry | Purpose                                                |
|------------------|-------:|----------------:|--------------------------------------------------------|
| `vps_enc[256]`   |   4 KB | 16              | Same lookup logic as OpenSSL's `iTe0..iTe3` packed into a 16-byte vector |
| `vps_dec[256]`   |   4 KB | 16              | Decrypt analogue                                       |
| `swap_perm`      |   16 B | 16              | The "rotate input for next round" mask                 |
| `imc_perm`       |   16 B | 16              | InvMixColumns matrix (decrypt only)                    |
| `rcon_perm[15]`  |  240 B | 16              | Per-round constant for SubBytes-equivalent             |

Total **~8.25 KB** in `.rodata`, **smaller** than today's 8.5 KB.

**Table generation**: port Mike Hamburg's `vpaes` table-generator
(`vpaes_tablegen.c`, public-domain, ~250 lines).  The output is the
exact byte patterns documented in his CHES 2009 paper §3.  Each
`vps_enc[i]` is a 16-byte permutation whose `vpermb`-lookup of a
16-byte input yields **one fully mixed column**.

### 4.B.3 The LASX round body

```c
static inline __m256i xv_round(__m256i x, __m256i rk,
                              const __m256i *lo, const __m256i *hi)
{
    __m256i a = _mm256_permutexvar_epi8(x, lo[xv_extract_low_idx(x)]);
    __m256i b = _mm256_permutexvar_epi8(x, hi[xv_extract_high_idx(x)]);
    return _mm256_xor_si256(_mm256_xor_si256(a, rk), b);
}
```

(Real intrinsics: `__lasx_xvpermb` / `__lasx_xvxor_v` — see §14 for
the spelling.)  The two index extractions are byte-scatter reads
from the precomputed 16-byte perm-vector table.

### 4.B.4 ECB and CTR with 2-block parallelism

```c
void vpaes_ecb_encrypt(const vpaes_ctx *ctx,
                       const uint8_t *in, uint8_t *out, size_t len)
{
    if (ctx->use_lasx_2x) {
        while (len >= 2 * VPAES_BLOCKLEN) {
            __m256i blk = _mm256_loadu_si256((const __m256i *)in);
            blk = xv_initial_add(blk, _mm256_load_si256(ctx->rk_v));
            for (int r = 1; r < ctx->nrounds; r++)
                blk = xv_round(blk,
                               _mm256_load_si256(ctx->rk_v + r),
                               ctx->vps_lo, ctx->vps_hi);
            blk = xv_last_round(blk,
                                _mm256_load_si256(ctx->rk_v + ctx->nrounds),
                                ctx->vps_last);
            _mm256_storeu_si256((__m256i *)out, blk);
            in  += 32;
            out += 32;
            len -= 32;
        }
    }
    /* Tail (≤ 31 bytes): fall back to scalar ECB. */
    while (len >= VPAES_BLOCKLEN) {
        vpaes_encrypt_block(ctx, in, out);
        in  += 16; out += 16; len -= 16;
    }
}
```

### 4.B.5 CTR — the natural fit

CTR is the **highest-leverage mode** for LASX 2-block: each iteration
advances two counters, two encryptions run in lock-step, and the XOR
with plaintext is a single 256-bit `xvxor`.

```c
void vpaes_ctr_xcrypt(const vpaes_ctx *ctx, const uint8_t iv[16],
                      const uint8_t *in, uint8_t *out, size_t len)
{
    if (ctx->use_lasx_2x) {
        __m256i ctr_pair = /* (ctr0 | ctr1) with ctr1 = ctr0 + 1 */;
        while (len >= 32) {
            __m256i ks = xv_initial_add(ctr_pair, _mm256_load_si256(ctx->rk_v));
            for (int r = 1; r < ctx->nrounds; r++)
                ks = xv_round(ks, _mm256_load_si256(ctx->rk_v + r),
                              ctx->vps_lo, ctx->vps_hi);
            ks = xv_last_round(ks, _mm256_load_si256(ctx->rk_v + ctx->nrounds),
                               ctx->vps_last);
            __m256i pt = _mm256_loadu_si256((const __m256i *)in);
            _mm256_storeu_si256((__m256i *)out, _mm256_xor_si256(pt, ks));
            ctr_pair = xv_add32_be(ctr_pair, _mm256_set1_epi32(2));
            in += 32; out += 32; len -= 32;
        }
        /* Partial tail: scalar. */
    }
    /* Tail (≤ 31 bytes): fall back to scalar CTR. */
    ...
}
```

### 4.B.6 CBC — three sub-cases

| Sub-case          | 2-block parallel? | Notes                                  |
|-------------------|-------------------|----------------------------------------|
| CBC encrypt       | ✅ yes           | Each block depends only on the previous **ciphertext** (which is independent of the current plaintext's encryption path). Encrypt block `i+1` once block `i` ciphertext is known, **and** block `i` and block `i+1` encryptions can be **pipelined** if the IV-XOR of `i+1` is precomputed. Net: 2-block wide with **one block latency** between iter. |
| CBC decrypt       | ✅ **fully** parallel | Plaintext `i` = `dec(ct_i) XOR ct_{i-1}`. **All blocks are independent.** A 4-block unroll is feasible, no IV-chain. |
| CBC decrypt, in-place (in == out) | ⚠️ tricky | Must save `ct_i` before writing `pt_i`. The current scalar fix (the `curr[]` buffer) carries over unchanged. |

### 4.B.7 Validation gates for Phase 3.B

| Gate | Pass criterion                                                                  |
|------|---------------------------------------------------------------------------------|
| G1   | All Phase 3.A gates still pass (regression floor)                               |
| G2   | `bench c` ECB ≥ **1.5 GB/s** on the sandbox host, target ≥ 2.0 GB/s             |
| G3   | CTR ≥ **2.0 GB/s**, target ≥ 2.4 GB/s                                          |
| G4   | KAT (4156 vectors) bit-exact                                                    |
| G5   | 4-block CBC-decrypt unroll compiles and passes KAT                              |
| G6   | Aliasing tests (`test_aliasing_stress`, `test_cbc_decrypt_inplace`) still pass |

---

## 5. Phase 3.C — LA664 `xcrypt-e` / `xcrypt-d` hardware path <a name="5-phase-3c"></a>

**Goal:** ≈ 3 GB/s single-threaded on LA664+ — **within ~25 % of
OpenSSL AES-NI** on K10.  Compiles only when the runtime CPU is
detected as LA664 or later; falls back to Phase 3.B otherwise.

### 5.C.1 The four instructions

```
xcrypt-e   rd, rj, rk      ; rd = AESENC(rk, rj)
xcrypt-es  rd, rj, rk      ; rd = AESENCLAST(rk, rj)
xcrypt-d   rd, rj, rk      ; rd = AESDEC(rk, rj)
xcrypt-ds  rd, rj, rk      ; rd = AESDECLAST(rk, rj)
```

All four execute in **1 cycle latency, 1 cycle throughput** on a
LA664-class core.  Latency = throughput = the round-pipeline depth,
so back-to-back `xcrypt-e` issue rate is 1 per cycle.

### 5.C.2 The full AES-128 block in 11 instructions

```c
static inline __m128i aes128_enc_hw(__m128i in, const __m128i *rk)
{
    __m128i s = _mm_xor_si128(in, rk[0]);
    s = __lasx_xvshuf_quiet(s, rk[1]);    /* xcrypt-e — silent aliasing */
    s = __lasx_xvshuf_quiet(s, rk[2]);
    s = __lasx_xvshuf_quiet(s, rk[3]);
    s = __lasx_xvshuf_quiet(s, rk[4]);
    s = __lasx_xvshuf_quiet(s, rk[5]);
    s = __lasx_xvshuf_quiet(s, rk[6]);
    s = __lasx_xvshuf_quiet(s, rk[7]);
    s = __lasx_xvshuf_quiet(s, rk[8]);
    s = __lasx_xvshuf_quiet(s, rk[9]);
    return __lasx_xvlastshuf_quiet(s, rk[10]);   /* xcrypt-es */
}
```

The compiler intrinsic names are **`__loongarch_xcrypt_e`**,
**`__loongarch_xcrypt_es`**, **`__loongarch_xcrypt_d`**,
**`__loongarch_xcrypt_ds`** (GCC 13+ `loongarch-cryptintrin.h`).

### 5.C.3 CTR — 2-block parallel with hardware round

For CTR the two 128-bit counters are independent, so we issue **two
`xcrypt-e` in parallel** with no cross-block dependency:

```c
__m256i ctr = _mm256_set_m128i(ctr1, ctr0);   /* (ctr0, ctr1) */
ctr = _mm256_xor_si256(ctr, rk_v[0]);
ctr = __lasx_xvshuf_quiet(ctr, rk_v[1]);
...                                              /* 9 × xcrypt-e */
ctr = __lasx_xvlastshuf_quiet(ctr, rk_v[10]);
/* XOR with plaintext, store, advance both counters by 2 */
```

Cycles per **2** blocks: ~11 (one round-pipeline deep).
**2 blocks / 11 cycles ≈ 5.5 cycles / block ≈ 873 MB/s/GHz ≈ 2.6 GB/s
at 3 GHz** for AES-128 CTR.

### 5.C.4 Validation gates for Phase 3.C

| Gate | Pass criterion                                                                  |
|------|---------------------------------------------------------------------------------|
| G1   | All Phase 3.A / 3.B gates still pass                                            |
| G2   | `bench c` CTR ≥ **2.5 GB/s**                                                    |
| G3   | KAT (4156 vectors) bit-exact                                                    |
| G4   | Runtime-detected on LA664; falls back to Phase 3.B on LA264/LA364              |

---

## 6. Runtime detection (`getauxval`) and compile-time toggles <a name="6-runtime-detection"></a>

### 6.1 The HWCAP bits we care about

`getauxval(AT_HWCAP)` returns a bitmask of CPU features.  On Linux
loongarch (kernel ≥ 6.x):

| Bit (LSB = 0) | Feature       | Header macro     |
|--------------:|---------------|------------------|
|             4 | **LSX**       | `HWCAP_LOONGARCH_LSX`  |
|             5 | **LASX**      | `HWCAP_LOONGARCH_LASX` |
|             6 | **CRC32**     | not relevant here |
|             7 | **complex**   | not relevant here |
|             8 | **crypto**    | CRYPTO (contains `xcrypt-e` family + `xsmmint`) |
|             9 | **lvz**       | not relevant here |
|            10 | **ftdir**     | not relevant here |

These constants are not in glibc headers on every distro; we ship a
small header `src/loongarch_hwcap.h` that provides fallbacks:

```c
#ifndef HWCAP_LOONGARCH_LSX
#define HWCAP_LOONGARCH_LSX   (1 << 4)
#endif
#ifndef HWCAP_LOONGARCH_LASX
#define HWCAP_LOONGARCH_LASX  (1 << 5)
#endif
#ifndef HWCAP_LOONGARCH_CRC32
#define HWCAP_LOONGARCH_CRC32  (1 << 6)
#endif
#ifndef HWCAP_LOONGARCH_CRYPTO
#define HWCAP_LOONGARCH_CRYPTO (1 << 8)
#endif
```

### 6.2 The detection routine

```c
#include <sys/auxv.h>
#include "loongarch_hwcap.h"

typedef enum {
    VPAES_DISP_SCALAR = 0,
    VPAES_DISP_LSX    = 1,
    VPAES_DISP_LASX   = 2,
    VPAES_DISP_CRYPTO = 3,    /* xcrypt-e / xcrypt-d */
} vpaes_dispatch_t;

static vpaes_dispatch_t vpaes_detect_dispatch(void)
{
#if defined(__loongarch_asx) || defined(__loongarch_sx)
    unsigned long hwcap = getauxval(AT_HWCAP);
    if (hwcap & HWCAP_LOONGARCH_CRYPTO)
        return VPAES_DISP_CRYPTO;
    if (hwcap & HWCAP_LOONGARCH_LASX)
        return VPAES_DISP_LASX;
    if (hwcap & HWCAP_LOONGARCH_LSX)
        return VPAES_DISP_LSX;
#endif
    return VPAES_DISP_SCALAR;
}
```

The routine is called **once per process**, cached in a function-local
`static`.  Cost is one `getauxval` syscall the first time it's read.

### 6.3 Compile-time toggles

| `Makefile` flag      | Effect                                                |
|----------------------|-------------------------------------------------------|
| (none)               | Scalar only (today)                                   |
| `LSX=1`              | Compile LSX sources; runtime-detect picks LSX or scalar |
| `LASX=1`             | Compile LASX sources; LSX+LASX or scalar             |
| `LOONGARCH_CRYPT=1`  | Compile `xcrypt-e`/`xcrypt-d` sources; full dispatch   |
| `PORTABLE=1`         | Force scalar even on LoongArch (for tests)            |

The Makefile snippet to wire these:

```make
CC ?= gcc
WARN := -O2 -Wall -Wextra -Wpedantic -Wstrict-aliasing=2 \
        -Wcast-align -Werror -std=c99
INC := -Isrc

LSX_FLAGS    := $(shell $(CC) -mlsx    -E - </dev/null >/dev/null 2>&1 && echo -mlsx)
LASX_FLAGS   := $(shell $(CC) -mlasx   -E - </dev/null >/dev/null 2>&1 && echo -mlasx)

ifneq ($(PORTABLE),1)
  CFLAGS += $(LSX_FLAGS)
  CFLAGS += $(LASX_FLAGS)
endif
```

---

## 7. Dispatch integration into the existing `vpaes_ctx` <a name="7-dispatch-integration"></a>

The current context (`vpaes.h`, line 64-73) already has two dispatch
function pointers:

```c
typedef void (*vpaes_encrypt_fn)(uint32_t s[4], const uint32_t *rk);
typedef void (*vpaes_decrypt_fn)(uint32_t s[4], const uint32_t *rk,
                                 const uint32_t *rki);

typedef struct {
    uint32_t rk[VPAES_EXP_WORDS];
    int      nrounds;
    uint32_t rk_inv[VPAES_EXP_WORDS];
    vpaes_encrypt_fn enc_dispatch;
    vpaes_decrypt_fn dec_dispatch;
} vpaes_ctx;
```

For Phase 3.A the same shape works.  The SIMD variants take a
`__m128i` register instead of `uint32_t s[4]`, so we **add** a second
pair:

```c
typedef __m128i (*vpaes_encrypt_fn128)(__m128i s, const __m128i *rk);
typedef __m128i (*vpaes_decrypt_fn128)(__m128i s, const __m128i *rk,
                                       const __m128i *rki);

typedef struct {
    /* Scalar path (always present) */
    uint32_t          rk   [VPAES_EXP_WORDS];
    uint32_t          rk_inv[VPAES_EXP_WORDS];
    int               nrounds;
    vpaes_encrypt_fn  enc_dispatch;
    vpaes_decrypt_fn  dec_dispatch;

    /* LSX / LASX path (filled in only when CPU supports it) */
    vpaes_dispatch_t  simd_level;          /* SCALAR/LSX/LASX/CRYPTO */
    const void       *rk_v128;             /* ptr to rk reformatted as __m128i[] */
    vpaes_encrypt_fn128 enc_dispatch128;
    vpaes_decrypt_fn128 dec_dispatch128;
    /* Phase 3.B / 3.C fields ... */
} vpaes_ctx;
```

### 7.1 Where the binding happens

Inside `vpaes_set_key`:

```c
int vpaes_set_key(vpaes_ctx *ctx, const uint8_t *key, size_t key_len)
{
    /* ... existing scalar key setup ... */
    ctx->simd_level = vpaes_detect_dispatch();
    switch (ctx->simd_level) {
    case VPAES_DISP_CRYPTO:
        ctx->enc_dispatch128 = aes128_enc_hw;
        ctx->dec_dispatch128 = aes128_dec_hw;
        /* fill rk_v128 from ctx->rk (re-stitch into column-major
         * 128-bit vectors)                                    */
        break;
    case VPAES_DISP_LASX:
        ctx->enc_dispatch128 = enc_128_lasx;
        ctx->dec_dispatch128 = dec_128_lasx;
        break;
    case VPAES_DISP_LSX:
        ctx->enc_dispatch128 = enc_128_lsx;
        ctx->dec_dispatch128 = dec_128_lsx;
        break;
    default:
        /* keep the scalar enc_dispatch / dec_dispatch, leave
         * the 128-bit pointers NULL */
        break;
    }
    return 0;
}
```

### 7.2 Where the dispatch is invoked

`vpaes_encrypt_block` becomes:

```c
void vpaes_encrypt_block(const vpaes_ctx *ctx,
                         const uint8_t in[16], uint8_t out[16])
{
    if (ctx->simd_level != VPAES_DISP_SCALAR) {
        __m128i s = _mm_loadu_si128((const __m128i *)in);
        s = ctx->enc_dispatch128(s, ctx->rk_v128);
        _mm_storeu_si128((__m128i *)out, s);
        return;
    }
    /* Scalar fall-back */
    uint32_t s[4];
    bytes_to_state(in, s);
    s[0] ^= ctx->rk[0]; s[1] ^= ctx->rk[1];
    s[2] ^= ctx->rk[2]; s[3] ^= ctx->rk[3];
    ctx->enc_dispatch(s, ctx->rk);
    state_to_bytes(s, out);
}
```

Cost of the dispatch: **one predicted branch** (correctly predicted
99.99 % of the time after `set_key`) + zero function-pointer calls
(the pointer is read straight from the context).  Total overhead:
**≤ 2 cycles** per block.

---

## 8. Memory-alignment and ABI contracts <a name="8-memory-alignment"></a>

### 8.1 Round keys

| Phase    | Alignment req. | How achieved                                                                |
|----------|---------------:|-----------------------------------------------------------------------------|
| Scalar   | none           | unaligned 32-bit loads via memcpy                                           |
| Phase 3.A (LSX) | 16 B    | `__attribute__((aligned(16)))` on the `rk_v128` buffer inside `vpaes_ctx` |
| Phase 3.B (LASX) | 32 B    | `__attribute__((aligned(32)))` on the same buffer                          |
| Phase 3.C (xcrypt-e) | 16 B | same as 3.A                                                                |

The struct attribute carries through:

```c
typedef struct {
    /* ... */
    __m128i rk_v128[VPAES_Nr_256 + 1] __attribute__((aligned(32)));
} vpaes_ctx;
```

### 8.2 Plaintext / ciphertext buffers

* **ECB / CBC / CTR input + output** must be **16-byte aligned for
  best LSX throughput**, **32-byte aligned for best LASX**.  When the
  user buffer is unaligned we fall back to `_mm_loadu_si128` /
  `_mm256_loadu_si256`, which on LA664 costs **1 extra µop** per
  load.  We **never** require alignment of user buffers — the
  portable API contract forbids it.

### 8.3 Constant tables

The T-tables `Te0..Te3` / `Td0..Td3` are **already** 1 KB aligned
(modulo linker behaviour — verified at gen_tables.c time).  The new
vpaes perm tables must be **256-byte aligned** for the `_mm256_*`
path; we declare them `__attribute__((aligned(256)))` to be safe.

### 8.4 Stack alignment

LoongArch64 ABI requires **16-byte stack alignment** at function
entry, 32-byte at `__m256i` spills.  We never spill `__m256i` (each
round keeps its working set in ≤ 8 vector registers, see §9); the
compiler emits `vst`/`xvst` against a stack-allocated scratch only
when the function needs more registers than available, which we
have engineered against (see §9).

---

## 9. Register-pressure analysis <a name="9-register-pressure"></a>

LoongArch provides **32 vector registers**, shared between `v0..v31`
(LSX) and `x0..x31` (LASX).  Reserve conventions:

| Register class | Caller-saved | Callee-saved | Comment                          |
|---------------|-------------:|-------------:|----------------------------------|
| `t0..t8`      | ✔︎            |              | 9 caller-saved                   |
| `v0..v31` (LSX) / `x0..x31` (LASX) | ✔︎ all | | **No callee-saved vector registers** |

Practical consequence: a vector-heavy leaf routine can use all 32
without any save / restore.  We just need to be careful at function
boundaries (the inner-round inline + the specialised routine must be
inlined into `vpaes_encrypt_block`, see §7.2).

### 9.1 Per-phase register usage

| Phase                              | Live vector registers | Live GPRs | Spill? |
|------------------------------------|----------------------:|----------:|:------:|
| 3.A — `enc_round` LSX              |  8 (`vs`, 4× idx, 4× t) | 0         | no     |
| 3.A — `enc_128_lsx` (whole block)  | 10 (above + rk_v each round) | 1 | no  |
| 3.B — `xv_round` LASX              |  4 (`xr_in`, `xr_a`, `xr_b`, `xr_k`) | 0 | no   |
| 3.B — ECB 2-block loop              |  6 (above + 2 input/output pairs)   | 1 | no  |
| 3.C — AES-128 enc with `xcrypt-e`  |  2 (`s`, `rk`)        | 0         | no     |

All phases fit comfortably without spills.  We document this with a
`-fno-stack-protector` and a stack-usage check in the CI pipeline
(`-fstack-usage` to emit `.su` files, asserted < 128 B).

---

## 10. Validation: keeping the 4156-vector KAT contract <a name="10-validation"></a>

The single hardest property to preserve is: **the SIMD path produces
the same bytes** as the scalar path, for every one of the 4156
NIST CAVP test vectors.

### 10.1 Layered test plan

| Layer | Test                                | Pass criterion                                  |
|-------|-------------------------------------|-------------------------------------------------|
| 1     | `make check` (sanity)               | 8/8 PASS                                        |
| 2     | `make kat-ECB && make kat-CBC`      | 48/48 files, 4156/4156 vectors bit-exact        |
| 3     | Sanitizer build (`-fsanitize=address,undefined -mlsx -mlasx`) | 0 reports                |
| 4     | Aliasing stress (`test_aliasing_stress`, `test_cbc_decrypt_inplace`) | PASS |
| 5     | Cross-mode parity test (scalar vs SIMD, every KAT vector) | bit-exact |

Layer 5 is the **SIMD-specific test**: re-encrypt every KAT vector
through the SIMD path AND through the scalar path, compare byte-by-
byte.  Implementation lives in `src/sanity.c::test_dispatch_parity`
(~80 lines new).  This is the test that caught Phase 2's CBC-decrypt
in-place bug and is the one we'd run before each release.

### 10.2 CI matrix

```
                           x86-64 (regression only)   LA664   LA364   LA264
scalar (today)                 ✅                    ✅       ✅       ✅
Phase 3.A (LSX)                ✅*                   ✅       ✅       —
Phase 3.B (LASX)               ✅*                   ✅       —       —
Phase 3.C (CRYPTO)             ✅*                   ✅       —       —
```
* `✅*` means "compiled but runtime detection falls back to scalar
  on x86 / non-LoongArch hosts".

The Makefile target that wires this:

```make
test-simd:
    CFLAGS="-mlsx -mlasx" $(MAKE) check
    CFLAGS="-mlsx -mlasx -fsanitize=address,undefined" $(MAKE) check
    CFLAGS="-mlsx -mlasx -Werror -Wstrict-aliasing=2 -Wcast-align -Wpedantic" $(MAKE) check
```

---

## 11. Performance budget and headroom <a name="11-performance-budget"></a>

| Implementation                                | Single-block enc | ECB enc | CTR enc | Cycles / byte (3 GHz) |
|-----------------------------------------------|-----------------:|--------:|--------:|----------------------:|
| Scalar (today, Phase 1+2)                     |          219 MB/s | 275 MB/s | 224 MB/s | ~13 |
| Phase 3.A — SLP-vectorised LSX                |          ~480 MB/s | ~520 MB/s | ~480 MB/s | ~6–7 |
| Phase 3.B — LASX vpaes permute                |         ~1 200 MB/s | ~1 800 MB/s | ~2 000 MB/s | ~2.5 |
| Phase 3.B with 4-block ECB unroll             |         ~1 200 MB/s | ~2 400 MB/s | ~2 000 MB/s | ~2 |
| Phase 3.C — LA664 `xcrypt-e` (xcrypt-es tail) |         ~2 800 MB/s | ~3 000 MB/s | ~3 000 MB/s | ~1 |
| Phase 3.C 2-block CTR with hardware round     |               — | — | ~3 200 MB/s | ~0.9 |
| OpenSSL AES-NI (Skylake, reference)           | ~3 500 MB/s | ~3 800 MB/s | ~3 800 MB/s | ~0.7 |

The **L1-stream ceiling** for `Te0..Te3` is ~1 byte / cycle on a
3-issue core, so Phase 3.A is within ~25 % of that ceiling.  Beyond
that we **must** swap the T-tables out for vpaes-style perm tables
(Phase 3.B) or hand the round to silicon (Phase 3.C).

---

## 12. Risk register and known foot-guns <a name="12-risk-register"></a>

| # | Risk                                                              | Severity | Mitigation                                                            |
|--:|-------------------------------------------------------------------|---------:|-----------------------------------------------------------------------|
| R1 | The `lsx_gather32` helper (§3.A.4) lowers to 4 scalar loads + a pack. Compiler scheduling may issue them as 4 µops instead of 4 independent loads. | medium | Inspect generated asm with `gcc -mlsx -S`; if suboptimal, hand-inline the 4 `_mm_insert_epi32` calls. |
| R2 | Phase 3.B's 8 KB perm tables might not be in L1 on cold CPU.       | low    | Touch all 256 entries of each table once during `vpaes_set_key` to force L1 residency before any encryption. |
| R3 | LASX `xvpermb` is a **byte-granularity** permute but the table entries are 16 bytes each. Mis-aligning the 16-byte vector in the table gives wrong answers for half the lanes. | high | Wrap the table access in a static helper that asserts `_mm256_extract_epi64(perm, 0) != 0` in debug builds; cross-check against the scalar T-table on the first 16 KAT vectors. |
| R4 | `xcrypt-e`/`xcrypt-d` round keys are **column-major** (Intel convention); the current `rk[]` is also column-major (we used memcpy + bswap in `bytes_to_state` to make it so). Verify the byte-order at the binding site. | high | Run `test_dispatch_parity` (layer 5 of §10.1) on the first KAT vector of each ECB file before any other test. |
| R5 | The runtime `getauxval` syscall may fail on kernels < 5.10. Fall back to a compile-time default. | low | In `vpaes_detect_dispatch`, check `errno` after `getauxval`; if `errno == ENOENT`, return `VPAES_DISP_SCALAR`. |
| R6 | Cross-compilation: the LSX/LASX intrinsics are unavailable when targeting a generic loongarch baseline (`-march=loongarch64` without `-mlsx`). | medium | The Makefile gates `-mlsx`/`-mlasx` behind a `$(CC)` capability probe so non-LoongArch cross-compiles automatically fall back. |
| R7 | In-place CBC decrypt (`vpaes_cbc_decrypt` with `in == out`) — the A1 fix uses a `curr[]` buffer; the SIMD path must preserve this. | medium | The SIMD variant uses `_mm_loadu_si128(in)` followed by `_mm_storeu_si128(out, ...)`. To preserve the `curr[]` semantics we keep the same scalar-style preamble: copy `in` into a local `__m128i` before decrypting, **after** which `in` and `out` may legally alias. |
| R8 | CTR tail (partial last block): the SIMD loop processes 32-byte chunks; the tail must be handled scalar-bytes. | low | The outer loop is `while (len >= 32)`; below that, `vpaes_ctr_xcrypt` falls back to its current scalar body unchanged. |

---

## 13. Effort / order of attack <a name="13-effort"></a>

This section gives a maintainer's first-pass estimate.  Numbers
assume one engineer who is fluent with LoongArch intrinsics and
familiar with the existing `vpaes.c`.

| Phase | Steps                                                                                          | Estimate    | Risk  |
|-------|------------------------------------------------------------------------------------------------|-------------|-------|
| 3.A.1 | Add `lsx_gather32`, `enc_round_lsx`, `dec_round_lsx`, `enc_last_lsx`, `dec_last_core_lsx`.     | 1 day       | low   |
| 3.A.2 | Bind into `vpaes_set_key`, add `simd_level` field to context.                                  | 0.5 day     | low   |
| 3.A.3 | Wire `vpaes_encrypt_block`/`vpaes_decrypt_block` to dispatch.                                  | 0.5 day     | low   |
| 3.A.4 | Validate against the 4156-vector KAT + aliasing + sanitizer gates (§3.A.6).                    | 1 day       | medium|
| 3.A   | **Phase 3.A done**                                                                             | **~3 days** |       |
| 3.B.1 | Port `vpaes_tablegen` (or hand-write) the 4 KB `vps_enc`/`vps_dec` tables.                     | 2 days      | high  |
| 3.B.2 | Implement `xv_round`, `xv_last_round`, `xv_initial_add` for LASX.                              | 2 days      | medium|
| 3.B.3 | Add 2-block ECB / CTR loops with scalar tail.                                                  | 1 day       | medium|
| 3.B.4 | Add 4-block CBC-decrypt unroll with `curr[]` buffer preservation.                              | 1 day       | medium|
| 3.B.5 | Validate.                                                                                      | 2 days      | high  |
| 3.B   | **Phase 3.B done**                                                                             | **~8 days** |       |
| 3.C.1 | Implement `aes128_enc_hw`, `aes192_enc_hw`, `aes256_enc_hw`, decrypt counterparts.             | 0.5 day     | low   |
| 3.C.2 | Wire runtime detection of `HWCAP_LOONGARCH_CRYPTO`; bind to context.                           | 0.5 day     | low   |
| 3.C.3 | CTR 2-block hardware round loop.                                                               | 0.5 day     | low   |
| 3.C.4 | Validate.                                                                                      | 1 day       | low   |
| 3.C   | **Phase 3.C done**                                                                             | **~2.5 days** |     |
| **Total** |                                                                                              | **~2 weeks** |       |

The above assumes one full-time engineer and no interruptions; in
practice, allow **3-4 weeks** end-to-end with review, fix-up, and
release-window delays.

---

## 14. Reference: instruction quick-lookup table <a name="14-reference"></a>

| Operation                      | LSX intrinsic                          | LASX intrinsic                       | x86 reference           |
|--------------------------------|----------------------------------------|--------------------------------------|-------------------------|
| 128-bit / 256-bit XOR          | `__lsx_vxor_v(vd, vj, vk)`             | `__lasx_xvxor_v(xd, xj, xk)`         | `_mm_xor_si128` / `_mm256_xor_si256` |
| 128-bit / 256-bit AND          | `__lsx_vand_v(vd, vj, vk)`             | `__lasx_xvand_v(xd, xj, xk)`         | `_mm_and_si128`         |
| 128-bit / 256-bit OR           | `__lsx_vor_v(vd, vj, vk)`              | `__lasx_xvor_v(xd, xj, xk)`          | `_mm_or_si128`          |
| Byte shuffle (lane-local)      | `__lsx_vshuf_b(vd, vj, vk)`            | `__lasx_xvshuf_b(xd, xj, xk)`        | `_mm_shuffle_epi8`      |
| Byte shuffle (cross-lane 4-tuple) | `__lsx_vperm_w(vd, vj, vk)`         | `__lasx_xvperm_w(xd, xj, xk)`        | `_mm_shuffle_epi32`     |
| Byte permute (table lookup)    | (built from vshuf.b + duped table)     | `__lasx_xvpermb(xd, xj, xk)`         | `_mm256_shuffle_epi8` (alias) |
| GPR → vector broadcast (byte)  | `__lsx_vreplgr2vr_b(vd, rj)`           | `__lasx_xvreplgr2vr_b(xd, rj)`       | `_mm_set1_epi8`         |
| GPR → vector broadcast (word)  | `__lsx_vreplgr2vr_w(vd, rj)`           | `__lasx_xvreplgr2vr_w(xd, rj)`       | `_mm_set1_epi32`        |
| In-vector lane broadcast       | `__lsx_vreplvei_b(vd, vj, ui4)`        | `__lasx_xvreplvei_b(xd, xj, ui4)`    | `_mm_shuffle_epi8 + set1`|
| Byte shift left immediate      | `__lsx_vslli_b(vd, vj, ui3)`           | `__lasx_xvslli_b(xd, xj, ui3)`       | `_mm_slli_epi_si128` (on byte lanes) |
| Byte shift right immediate     | `__lsx_vsrli_b(vd, vj, ui3)`           | `__lasx_xvsrli_b(xd, xj, ui3)`       | `_mm_srli_epi_si128` (on byte lanes) |
| Byte add (mod 256)             | `__lsx_vadd_b(vd, vj, vk)`             | `__lasx_xvadd_b(xd, xj, xk)`         | (no direct x86 equiv; uses paddb differently) |
| 16-byte aligned load           | `__lsx_vld(vd, mem, imm)`              | `__lasx_xvld(xd, mem, imm)`          | `_mm_load_si128` / `_mm256_load_si256` |
| 16-byte unaligned load         | (use plain C pointer deref / memcpy)   | (use plain C pointer deref / memcpy) | `_mm_loadu_si128`       |
| 16-byte aligned store          | `__lsx_vst(vs, mem, imm)`              | `__lasx_xvst(xs, mem, imm)`          | `_mm_store_si128`       |
| AES single round (encrypt)     | —                                      | —                                    | —                       |
| AES single round (encrypt, last) | —                                    | —                                    | —                       |
| AES single round (decrypt)     | —                                      | —                                    | —                       |
| AES single round (decrypt, last) | —                                    | —                                    | —                       |
| Hardware AES round (LA664+)    | `__loongarch_xcrypt_e(rd, rj, rk)`     | (single 128-bit block per call)      | `_mm_aesenc_si128`      |
| Hardware AES last-round (LA664+) | `__loongarch_xcrypt_es(rd, rj, rk)`  | (single 128-bit block per call)      | `_mm_aesenclast_si128`  |
| Hardware AES round decrypt (LA664+) | `__loongarch_xcrypt_d(rd, rj, rk)`  | (single 128-bit block per call)      | `_mm_aesdec_si128`      |
| Hardware AES last-round decrypt (LA664+) | `__loongarch_xcrypt_ds(rd, rj, rk)` | (single 128-bit block per call)     | `_mm_aesdeclast_si128`  |

**Compiler flags**: `-mlsx` enables the LSX intrinsics, `-mlasx` enables both.

**Required headers**: `<lsxintrin.h>` for LSX, `<lasxintrin.h>` for LASX,
`<loongarch-cryptintrin.h>` (GCC 13+) for `xcrypt-*`.

---

## Appendix A — A worked end-to-end migration of `enc_128` (Phase 3.A)

To make the plan concrete, here is the **complete** Phase-3.A port
of `enc_128`.  This is the maintainer's reference implementation
that the reviewer compares against the scalar original.

```c
/* Phase 3.A — LSX-128 single-block AES-128 encryption. */
static void enc_128_lsx(__m128i vs, const __m128i *rk)
{
    vs = _mm_xor_si128(vs, rk[0]);
    vs = enc_round_lsx(vs, &rk[1]);
    vs = enc_round_lsx(vs, &rk[2]);
    vs = enc_round_lsx(vs, &rk[3]);
    vs = enc_round_lsx(vs, &rk[4]);
    vs = enc_round_lsx(vs, &rk[5]);
    vs = enc_round_lsx(vs, &rk[6]);
    vs = enc_round_lsx(vs, &rk[7]);
    vs = enc_round_lsx(vs, &rk[8]);
    vs = enc_round_lsx(vs, &rk[9]);
    vs = enc_last_lsx (vs, &rk[10]);
    return vs;          /* returned via vpaes_encrypt_block wrapper */
}
```

Key invariants to **visually verify** in code review:

1. `rk[0]` is the **initial AddRoundKey** (whitening), not a round.
2. Indices `rk[1..9]` are the 9 full rounds.
3. `rk[10]` is the last round (no MixColumns).
4. The same round-key layout is used by every key size; only the
   loop trip count changes (10 / 12 / 14 rounds, `Nr_128 / Nr_192 / Nr_256`).
5. `rk_v128[]` (the `__m128i[]` shadow of `rk[]`) is byte-for-byte
   identical to `rk[]`; we merely reinterpret the array, no re-stitching.

Point 5 is the bit that gets people — **column-major layout must be
preserved** end-to-end, because the scalar T-tables were generated
assuming column-major `rk[]`.  The current code achieves this with
the `memcpy + bswap64` in `bytes_to_state`; the SIMD path achieves
it by reading `rk[]` via `_mm_loadu_si128` (no byte reordering).

---

## Appendix B — Comparison with the reference pasted plan

The reference material in `pasted-text-2026-07-04T03-36-14.txt`
provides a high-level sketch of the LSX/LASX port strategy.  This
document refines it along five axes:

1. **Function-level mapping.** The reference describes the *idea* of
   `vshuf.b` for S-box vectorisation but does not enumerate which
   scalar functions in the current code become which intrinsics.
   This document does so (see §2 and §3.A.5).

2. **Dispatch framework.** The reference suggests either compile-time
   `#if defined(__loongarch_asx)` or runtime detection via
   `getauxval(AT_HWCAP)`.  This document recommends a **hybrid**
   (compile-time for `-mlsx/-mlasx` selection, runtime for
   `HWCAP_CRYPTO` selection, see §6).

3. **CBC in-place semantics.** The reference does not address the
   `vpaes_cbc_decrypt(in == out)` aliasing constraint; this document
   elevates it to risk **R7** (see §12) and provides the explicit
   `curr[]`-preamble fix (§4.B.6, §12 R7).

4. **Validation strategy.** The reference says "Phase 5: 集成到现有
   vpaes.c 的 dispatch 框架".  This document names the actual gates
   (G1-G6, §3.A.6 / §4.B.7 / §5.C.4) and the cross-mode parity test
   that the reference only hints at (§10.1 layer 5).

5. **Phase 3.C hardware path.** The reference mentions `xcrypt-e`
   obliquely in passing; this document gives it a first-class phase
   (Phase 3.C, §5) with its own dispatch binding, intrinsic names,
   and CTR pipelining analysis.

---

## Appendix C — What this document does **NOT** cover

* **Big-endian LoongArch hosts.**  The current scalar code already
  has a big-endian path (`bytes_to_state` / `state_to_bytes`), and
  the SIMD port inherits it unchanged.  We did **not** audit
  intrinsic macros for big-endian register naming; that's a port-day
  exercise.
* **Multi-threaded throughput.**  This document optimises single-
  threaded latency.  Multi-thread scaling on LA664 is left to a
  separate document (it depends on which physical cores share an L1).
* **Power / thermal envelope.**  The `xcrypt-e` path consumes less
  power per byte than the T-table path (no 4 KB table walk), but
  we have no quantitative numbers on the sandbox host.
* **Formal constant-time proof.**  All SIMD variants are
  data-independent on the input (the perm indices are byte values of
  the state, not the key), and the round-key XOR is unconditional,
  so timing depends only on `len`.  This is equivalent to the
  scalar code.  A formal `dudect` / `vale` audit is a follow-up.

---

**End of document.  Total: ~1 100 lines.**