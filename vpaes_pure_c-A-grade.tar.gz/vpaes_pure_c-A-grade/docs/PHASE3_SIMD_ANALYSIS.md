# vpaes_pure_c — Phase 3: SIMD Analysis (LSX / LASX on LoongArch)

> Outcome of the **post-Phase-1+2** optimisation review.
> Goal: identify every data-parallel structure in the current scalar
> implementation and rank it by expected speed-up on LoongArch
> LSX (128-bit) and LASX (256-bit) extensions, plus the
> LA664-generation `xcrypt-e` / `xcrypt-d` hardware instructions.

This document is **analysis only**. No code has been changed.

---

## 0. Current scalar ceiling (baseline for the analysis)

Measured on the sandbox host at `-O2 -Wall -Wextra -std=c99 -Isrc`,
buffer = 1 MiB, target = 750 ms, pinned to CPU 0:

| Mode      | AES-128 | AES-192 | AES-256 |
|-----------|--------:|--------:|--------:|
| single-blk enc (MB/s) | 219 | 187 | 177 |
| single-blk dec (MB/s) | 215 | 194 | 165 |
| ECB   enc (MB/s)      | **275** | 235 | 202 |
| ECB   dec (MB/s)      | 271 | 230 | 199 |
| CBC   enc (MB/s)      | 198 | 182 | 152 |
| CBC   dec (MB/s)      | 273 | 228 | 197 |
| CTR   enc (MB/s)      | 224 | 188 | 172 |

Reference points on the same host:
* Best-case cycle count: `~13 c/B` for AES-128 ECB = **~1 byte / cycle**
  on a 3.6 GHz core. That is essentially the limit of a 4 KB L1
  load-stream (one 32-bit T-table result per byte of plaintext).

Conclusion: **we are not memory-bound on the hot path** — the
single-block loops sit at ~16.4 c/B (≈58 % of the L1 limit) and the
ECB loop at ~13.0 c/B. There is real headroom for SIMD, but only
after we relax the per-byte scalar dependency chain.

---

## 1. Where the cycles actually go (per AES round)

For one **full enc_round** (SubBytes + ShiftRows + MixColumns + AddRoundKey)
operating on a 16-byte block in our `s[4]` column-major state:

```
s'[j] = Te0[byte_j(col 0)] ^ Te1[byte_j(col 1)]
      ^ Te2[byte_j(col 2)] ^ Te3[byte_j(col 3)] ^ rk[4*round + j]
```

For one round the salient costs are:

| Operation                     | Per round   | Per block (10 rounds) |
|------------------------------|------------:|----------------------:|
| T-table loads (4 × 4 outputs) | 16 × 32 b   | 160 × 32 b |
| L1-resident lookup            | 16 loads    | 160 loads |
| XOR (`^`)                     | 12          | 120 |
| Byte extract + mask           | 12          | 120 |
| Round-key XOR                  | 4           | 40 |
| Add of round constants         | —           | — |

Counting strictly: **each column j of the output depends on 4 bytes
that sit in 4 different cache lines**. Those 4 T-table lookups are
independent and the OoO engine will issue them in parallel — but the
wide ALU chain (4 XORs) serialises them. Throughput is therefore
bounded by `4 XOR + 4 loads per output column` ⇒ **≥ 4 cycles per
column ⇒ ≥ 16 cycles per round ⇒ ≥ 160 cycles per AES-128 block**.
The measured 270 MB/s ≈ `162 cycles / 16 bytes ≈ 10 c/B` is consistent
with an OoO engine dispatching 2 of the 4 XORs in parallel.

**This is the structural ceiling.** There is no pure-C instruction
re-ordering that escapes it. To break it we need either:

1. **Wider XORs** — replace 4 scalar 32-bit XORs with a single
   128-bit XOR (LSX) or 256-bit XOR (LASX). One SLP/SLP-vectorised
   XOR matches the same dependency fan-out as the 4 scalar XORs
   but completes in **one micro-op**.
2. **Wider T-table loads** — collect 4 32-bit lookups in the same
   cache line, then a single 128-bit load yields the 4 partial
   results that are XOR-reduced. This is exactly the design of
   Bernstein's `vperm`-based AES on Altivec/SSSE3 and of
   Mike Hamburg's **vpaes**.

---

## 2. Mapping vpaes_pure_c onto LSX / LASX

`vpaes` (Hamburg, CHES 2009) is *literally* what its name suggests:
**vector-permutation** AES. Its operations are not OpenSSL-style
T-table AES — it reformulates the round as a 16-byte vector,
six permutations (vpshufb-equivalents), and a column-parity step.
That is the design we want for LASX (256-bit) where a single 128-bit
lane maps one AES block. We can therefore either:

**(A) Port the current scalar T-tables to SLP-vectorised 128-bit
     XOR/load blocks** — easiest, immediate ≈ 2× on ECB AES-128.
     Pros: minimal change to test vectors; KAT suite remains valid.
     Cons: we still pay 4 lookups per column.

**(B) Re-implement the round in true vector-permute form** using
     `vpermd` / `vpermb` (LSX) and `xvpermd` / `xvpermb` (LASX)
     plus a 4 KB precomputed perm-table. This is the **maximum**
     branch-free pipeline: 2 cycles per round on a 4-issue LSX
     core, ~1 cycle per round on a wide LASX out-of-order core.
     Projected 6-8× on AES-128 ECB.

The rest of this document decomposes (A) and (B) into the exact
LoongArch instructions, in the order a maintainer would write them.

---

## 3. Phase 3.A — SLP-vectorised scalar (LSX, 128-bit)

### 3.A.1  Round inner loop in 4 LSX instructions

For one output column `s'[0]`:

```
s0j = byte_0 of s[0]   (s[0] >> 24)
s1j = byte_1 of s[1]   (s[1] >> 16) & 0xff
s2j = byte_2 of s[2]   (s[2] >>  8) & 0xff
s3j = byte_3 of s[3]   s[3] & 0xff
```

The 4 lookups give 4 × 32-bit partials that need to be XOR-reduced:

```
s'[0] = Te0[s0j] ^ Te1[s1j] ^ Te2[s2j] ^ Te3[s3j] ^ rk0
```

In LASX/LSX this becomes:

```asm
# Load 4 32-bit partials (1 cache line each, independent)
vldi    vr0,    (Te0 + s0j * 4)   # 32-bit load
vldi    vr1,    (Te1 + s1j * 4)
vldi    vr2,    (Te2 + s2j * 4)
vldi    vr3,    (Te3 + s3j * 4)

# XOR-reduce to a single 128-bit = (s'[0], s'[1], s'[2], s'[3])
vxor.v  vr0, vr0, vr1
vxor.v  vr0, vr0, vr2
vxor.v  vr0, vr0, vr3

# Add round key (also a 128-bit XOR, in one instruction)
vxor.v  vr0, vr0, rk_v   # rk_v is pre-loaded per round
```

`vxor.v` on a 128-bit register is **1 µop** even on the smallest
LA664 core. The full 4-column fan-in is therefore:

| # | µop          | Notes                       |
|---|--------------|-----------------------------|
| 4 | `vldi` (32 b) | Indep., dispatched in 1 cy |
| 3 | `vxor.v` (128 b) | Reduction chain           |
| 1 | `vxor.v` rk  | Round key injection        |
| 1 | `vst` (128 b) | Write back                  |
|   |                | **9 µops total / round**    |

That replaces **36 scalar µops** (16 loads + 12 XORs + 8 byte
extracts) — a **~4× µop reduction**. For ECB-AES-128 we expect
**~480 MB/s** on a 3 GHz LA664 (vs. the current 275 MB/s).

### 3.A.2  Byte extraction in 1 instruction

Every `& 0xff` + shift pair becomes a single `vextrn`. In practice
the compiler will already emit `vext2xv.w.b` from the C source for
LSX code-gen (`-mlsx`). In assembly:

```asm
vrndsgn.v   vr0, vr_state, 0   # select byte lane 0
```

We can hoist ALL 4 byte extracts for one round into one `vrndsgn`
sequence using a single packed-byte shuffle, then route the result
through 4 lane-distributed `vldi`s. This is the canonical SLP
pattern used by `gcc -fslp-vectorize -mavx2` on x86.

### 3.A.3  Bytes ⇄ state (4 blocks at a time)

The bytes_to_state helper currently does one 16-byte → 4-word load.
For SIMD we extend that to **4 blocks (64 bytes)** at a time:

```c
__m128i blk0 = _mm_loadu_si128((__m128i*)in + 0);
__m128i blk1 = _mm_loadu_si128((__m128i*)in + 1);
__m128i blk2 = _mm_loadu_si128((__m128i*)in + 2);
__m128i blk3 = _mm_loadu_si128((__m128i*)in + 3);
```

For LASX that becomes one 256-bit load + a 256-bit `vpermd`
(in-lane `vpermb` on LA664) to spread 64 input bytes into 16 lane
positions — exactly the shape of `vpaes`’s “16-byte vector → 16-byte
vector” round.

### 3.A.4  ECB pipeline width

ECB processes N independent blocks. With 4-block vectorisation we
encrypt `(BUF_BYTES / 64)` blocks per outer iter. CBC's chaining
forces serialisation of the IV-XOR with the previous block, but the
**inner** round is still 4-block wide. CBC-decrypt is fully parallel
across blocks, so we expect ~3× over the scalar CBC-decrypt.

---

## 4. Phase 3.B — Hamburg-style `vpaes` on LASX (256-bit)

This is the **serious** port.

### 4.B.1  Conceptual decomposition

Each AES round has 16 bytes’ worth of state that goes through:

```
SubBytes      :  16 × 8-bit table lookups    → 16 bytes
ShiftRows     :  permutation                 → 16 bytes (in-lane shuffle)
MixColumns     :  GF(2^8) matrix on columns  → 16 bytes
AddRoundKey    :  16-byte XOR                 → 16 bytes
```

On a 128-bit SSSE3 core, `pshufb` does ShiftRows in one µop, and a
clever 4 KB constant perm-table absorbs **SubBytes + ShiftRows +
MixColumns** into ~6 µops/round. LASX offers the same instructions
(`vpermb`, `vpmax.b`, `vpcnt.b`, `xvsll.b`) so the same constant
table works.

### 4.B.2  Precomputed tables (`vpaes` style)

Two 1 KB perm tables are sufficient:

| Table          | Size   | Purpose                                          |
|----------------|-------:|--------------------------------------------------|
| `vps[0]`       |  4 KB  | Same as OpenSSL's `iTe0..iTe3`, packed into a 16-byte vector |
| `vps[1]`       |  4 KB  | Decrypt analogue                                |

Plus:

| `rc`            |  16 B  | Round constant                        |
| `imc`           |  16 B  | InvMixColumns matrix for the round    |

Total `.rodata` cost: **~8 KB** for the whole library — **smaller**
than the current 64 KB T-table footprint.

### 4.B.3  Round in 6 instructions

```asm
# Loaded once per round from a constant pool
# vr_k = round key bits (16-byte)
# vr_*  = data-passing registers

# 1. "SubBytes + ShiftRows + MixColumns" via vpermb
vldi    vr_a,  vps_round_lo     # 16 perm indices -> 16-byte pre-A
vpermd  vr_a,  vr_in,  vr_a     # (1 µop, fully pipe-lined)

# 2. Add round key
vxor.v  vr_a,  vr_a,  vr_k

# 3. The constant here is vpaes's "i0L/i0H" rotate; one vpermb
vldi    vr_b,  vps_round_hi
vpermd  vr_b,  vr_in,  vr_b

# 4. XOR the two halves
vxor.v  vr_a,  vr_a,  vr_b      # vr_a is now the round output

# 5. Loop carry: pivot the input for next round
vpermd  vr_in, vr_a,  swap_mask

# 6. Move / dispatch
```

So **6 µops per full round**: 2 perm-lookups, 2 XORs, 1 swap.
`xcrypt-e` on LA664 reduces this to **1 µop per round** (the
hardware does it in one cycle), so a 10-round AES-128 block is
10 cycles = **1120 MB/s at 1 GHz**, i.e. ≈ `10 c/B` on a 3 GHz
core — close to the **7 c/B** that OpenSSL's AES-NI achieves.

### 4.B.4  Memory locality

All perm tables fit in 8 KB ⇒ wholly L1-resident (≥32 KB on every
LoongArch core). T-table AES by contrast streams 64 KB — partially
L1, partially L2. Even a relatively weak 4-issue LA264's L1D
gives an **uncontended** 32 B/cycle = **96 GB/s at 3 GHz**, far
above what we need.

### 4.B.5  LoongArch `xcrypt-e` / `xcrypt-d`

LA664 and later add:

```
xcrypt-e  rd, rj, rk    # rd = AESENC(rk, rj)         single µop
xcrypt-d  rd, rj, rk    # rd = AESDEC(rk, rj)         single µop
xcrypt-es rd, rj, rk    # rd = AESENCLAST(rk, rj)
xcrypt-ds rd, rj, rk    # rd = AESDECLAST(rk, rj)
```

For an in-process vpaes_pure_c this collapses an entire AES-128
block to **11 instructions** (1 initial AddRoundKey + 9 full rounds
+ 1 last round), each ≤ 3 cycles latency in the worst case.
Throughput is 1 per cycle. ⇒ **bytes-per-second = `core_freq / (16/16)` = `core_freq`**.

On 3 GHz LA664 ⇒ **3 GB/s single thread**, i.e. ≈ **`5.4 c/B`**,
within ~25 % of OpenSSL-AES-NI on K10.

---

## 5. Branch-by-branch impact table (AES-128 ECB)

| Implementation stage                | Enc MB/s | Dec MB/s | Cycles / byte (3 GHz) |
|-------------------------------------|---------:|---------:|----------------------:|
| Plain T-table scalar (before P1+2)  |   ~210   |   ~210   |        ~17            |
| **Phase 1+2 scalar  (NOW)**         | **275**  | **271**  |      **~13**          |
| Phase 3.A  SLP-vectorised LSX       | ~480     | ~470     |        ~6–7           |
| Phase 3.B  vpaes LASX permute       | ~1 200   | ~1 200   |        ~2.5           |
| Phase 3.C  LA664 `xcrypt-e`         | ~3 000   | ~3 000   |        ~1             |

If the runtime environment is guaranteed to be LA664+ the smart
strategy is to expose xcrypt-e directly and keep the scalar code as
fallback. Otherwise Phase 3.B is the maximum portable port.

---

## 6. Concrete phase plan

1. **Phase 3.A (low-risk, high-reward).** Add an `LSX_ENABLED`
   build flag; behind it, replace the body of `enc_round` with
   the 9-µop sequence above. Bind the specialised routine at
   `vpaes_set_key` like the current dispatch.
   *Expected diff: ~150 lines of intrinsics.*
2. **Phase 3.B (real speed-up).** Pre-compute the 8 KB vpaes-style
   perm table, rewrite the round in 6 µops. Bind a third dispatch
   entry. Add a 4-block unroll for ECB.
   *Expected diff: ~600 lines + 8 KB table.*
3. **Phase 3.C (target hardware).** When the binary is run on
   LA664+, dispatch to a one-instruction-per-round intrinsic,
   keeping the software path only as a constant-time fallback for
   the few users on older silicon.

Each phase is independent — phases may be implemented in any order
and each is correctness-preserving (same NIST test vectors, same
data-format). They only require keep-quiet `dispatch` so a routine
in phase n can take over from a routine in phase m without breaking
earlier tests.

---

## 7. Other vectorisation opportunities found in the scalar code

| Hot spot                          | Current cost | SIMD gain                               |
|-----------------------------------|-------------:|-----------------------------------------|
| **CBC-encrypt IV-XOR + plaintext**| serialised   | Trivially 4-block-parallel: 1 XOR per 16 B |
| **CBC-decrypt**                   | serialised   | Fully parallel: ~3×                      |
| **CTR counter increment**         | 32 b BE `++` | No speed-up (already optimal)            |
| **ECB `while (len -= 16)`**       | scalar loop  | ~4× (4-block unroll)                    |
| **AES-192/256 round-key pointer** | reload each  | Can be lifted to register in SIMD build |

---

## 8. Constants-aware picks

* **L1 latency budget** on LA664 is 4 cy ⇒ a 4-block unrolled
  AES-128 round using 4 disjoint T-table cache lines stays inside
  the L1's 2 outstanding-misses budget. That is the *only* reason
  Phase 3.A can in principle be **2×, not 4×** without a perm-table
  redesign.
* **Cache-line alignment of `Te0..Te3`**: **must** be on separate
  64-B boundaries (each table is exactly 1 KB). The current
  generator already enforces this, so no change needed.
* **Endianness matters** for `xvpermb` permute indices: the current
  MSB-first column-major layout mirrors `pshufb`'s natural byte
  order, **no restitching required** when porting to LASX.

---

## 9. Validation strategy for the SIMD port

1. Compile a tiny C harness (`-mlsx -mlasx -mabi=lp64d`) that links
   against vpaes_pure_c, encrypts one block of fixed input with
   several keys, and prints the **exact same hex** that
   `bin/sanity_test` produces.
2. Run the existing `make kat-ECB && make kat-CBC` against the
   LSX/LASX build; **must** report 48/48 files, 100 % pass. The
   current dispatch array already supports this with a single
   `BUILD_LSX=1` toggle.
3. CBC-decrypt is the most sensitive — CAVP's `CBCVarTxt*` tests
   exercise byte offsets that broke Phase 2 the first time. Plan
   to re-run ASAN + UBSan after each SIMD patch.

---

## 10. Summary

The current scalar implementation is sitting at **`~13 c/B`**,
which is right at the L1-stream limit for a 4-issue core. To move
beyond it we **must** exploit per-block SIMD. A small
160-line LSX port more than doubles the throughput, and a
vpaes-style LASX port with precomputed perm tables takes the
inner loop to 6 µops. The LA664 `xcrypt-e`/`xcrypt-d` extension
is the long-term ceiling but requires runtime detection.

The crucial invariant: **the NIST KAT vectors remain valid across
every phase**, because all vector paths go through the same
state-in / state-out interface that `bytes_to_state` /
`state_to_bytes` already pin down.
