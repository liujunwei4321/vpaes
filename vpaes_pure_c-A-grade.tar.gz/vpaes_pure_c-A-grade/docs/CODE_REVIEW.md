# vpaes_pure_c — Comprehensive Code Review

**Scope**: `src/vpaes.h`, `src/vpaes.c`, `src/gen_tables.c`, `src/bench.c`,
`src/kat_test.c`, `src/sanity.c`, `Makefile`.

**Audit dimensions** (per the user's request):
1. Endianness compatibility (big-endian / little-endian correctness)
2. C99 syntax compliance (portability)
3. Common C-language bugs (UB, overflow, aliasing, type narrowing, etc.)

**Test evidence**: 5/5 sanity vectors pass (FIPS-197 Appx B/C.1/C.2/C.3,
SP 800-38A F.2.1, RFC 3686 §6). 48/48 NIST CAVP KAT files pass
(4156/4156 vectors). All correctness paths verified on x86-64 Linux.

---

## 1. Endianness

### 1.1 High-level strategy

The code uses a **compile-time branch** on `__BYTE_ORDER__` /
`__ORDER_LITTLE_ENDIAN__` (GCC/Clang macros) and ships **two
implementations** of the bytes↔state conversion:

| Path        | Location           | Strategy                                                    |
|-------------|--------------------|-------------------------------------------------------------|
| LE fast     | `bytes_to_state`   | two 64-bit unaligned loads + `__builtin_bswap64` + split    |
| LE fast     | `state_to_bytes`   | two 32-bit `bswap32` + two 64-bit unaligned stores          |
| BE safe     | `bytes_to_state`   | byte-by-byte, MSB-first packing                             |
| BE safe     | `state_to_bytes`   | byte-by-byte, MSB-first unpacking                           |

This is the right structure: state-internal byte order is **MSB-first
column-major** (the AES algebraic convention), independent of host
endianness. The conversion functions are the **only** places where
endianness matters.

### 1.2 Verdict — Endianness

| Aspect                                | Status | Note                                   |
|---------------------------------------|--------|----------------------------------------|
| Correct on x86-64 (LE)                | OK     | Validated against FIPS-197 / NIST KAT  |
| Correct on LoongArch LA664 (LE)       | OK     | Same code path; 64-bit loads are 0-cyc |
| Correct on a hypothetical BE host     | OK     | Falls through `#else` to byte loop     |
| Runtime endianness check              | None   | Compile-time is correct & faster       |

**There are no endianness correctness bugs.** The only thing the audit
caught is a *strict-aliasing* concern with the LE fast path (see
§3.4 below) — this is not an endianness bug per se but it appears in
the endian-dependent code.

### 1.3 Subtleties worth noting (informational, not bugs)

1. **`bytes_to_state` LE path** (vpaes.c:238): after `__builtin_bswap64`
   on `lo`, the high 32 bits hold `in[0..3]` in MSB-first order, low 32
   bits hold `in[4..7]`. The split `s[0] = lo >> 32`, `s[1] = lo` is
   correct.

2. **`state_to_bytes` LE path** (vpaes.c:261–262): after the previous
   fix, `bswap32(s[1])` occupies the upper 32 bits of `lo`, `bswap32(s[0])`
   the lower 32 bits. A 64-bit LE store then places the lower 32 bits at
   `out[0..3]` (which is `bswap32(s[0])`, i.e. `s[0]`'s bytes) and the
   upper 32 bits at `out[4..7]` (`bswap32(s[1])`). This is correct.
   The swapped order relative to the columns (`s[1]` high, `s[0]` low)
   is **required** for LE memory layout; the previous summary mentions
   this was once a bug and has been fixed.

3. **`Rcon` endianness** (vpaes.c:160): the Rcon value is XOR-ed in at
   the high byte via `<< 24`, which places it at `s[c] >> 24`. Since
   `s[c]` is in MSB-first packing (column word with column-0 byte in
   the most-significant position), this matches the FIPS-197
   convention. Correct on all hosts.

---

## 2. C99 Compliance

### 2.1 Non-C99 extensions found

| File              | Line(s) | Construct                                          | Status            |
|-------------------|---------|----------------------------------------------------|-------------------|
| vpaes.c           | 69      | `__attribute__((unused))`                          | GCC/Clang ext     |
| vpaes.c           | 222–223 | `__builtin_bswap32`                                 | GCC/Clang ext     |
| vpaes.c           | 232     | `__BYTE_ORDER__`, `__ORDER_LITTLE_ENDIAN__`         | GCC/Clang ext     |
| vpaes.c           | 238–239 | `__builtin_bswap64`                                 | GCC/Clang ext     |
| vpaes.c           | 256     | `__BYTE_ORDER__`, `__ORDER_LITTLE_ENDIAN__`         | GCC/Clang ext     |
| vpaes.h           | 51–52   | `__attribute__` is NOT used here                    | OK                |
| gen_tables.c      | 65      | `(x << 1)` where x is uint8_t — uses C int promotion| Standard C99 OK   |
| bench.c           | 19–24   | `_ISOC11_SOURCE` feature-test macro                 | C11 feature       |
| bench.c           | 139–140 | `aligned_alloc`                                     | C11, **not C99**  |
| bench.c           | 17, 23  | `_POSIX_C_SOURCE`, `_GNU_SOURCE` feature-test macros| POSIX/GNU         |
| bench.c           | 31      | `<sched.h>` + `sched_setaffinity` + `cpu_set_t`    | POSIX/GNU         |
| bench.c           | 30, 44  | `clock_gettime(CLOCK_MONOTONIC, ...)`              | POSIX 199309      |
| kat_test.c        | 26      | `<strings.h>` + `strcasecmp`                        | POSIX / BSD       |
| kat_test.c        | 27      | `<ctype.h>` + `isspace((unsigned char)*s)`         | C99 OK with cast  |
| kat_test.c        | 75, 77  | `isspace((unsigned char)*s)`                        | C99 OK with cast  |
| kat_test.c        | 28      | `<errno.h>` (unused — declared but never used)     | OK                |
| vpaes.h           | 4       | Comment typo "Implementaes" → "Implements"         | Cosmetic          |
| Makefile          | various | `?=`, `\|`, pattern rules, `$$fail`                | GNU make specific |

### 2.2 Detailed analysis

**vpaes.c:69 — `__attribute__((unused))`**:
Gates `-Wunused-const-variable` for the duplicated `isbox_unused[]`
table that mirrors the one in `gen_tables.c`. *Not in C99*. Mitigations:
(a) drop the array entirely (it is dead code — `gen_tables.c` is a
separate compile), or (b) guard with `#if defined(__GNUC__) ||
defined(__clang__)`. Severity: **low**, cosmetic build flag.

**vpaes.c:222, 238–239 — `__builtin_bswap32/64`**:
Both are wrapped in `#if defined(__GNUC__) || defined(__clang__)`
with a portable bit-rotation fallback. **The fallback in `bswap32` is
correct on any endianness host** (it rotates the bytes of `v`
intrinsically). Severity: **low** — already portable, just non-C99.

**vpaes.c:232, 256 — `__BYTE_ORDER__` / `__ORDER_LITTLE_ENDIAN__`**:
These macros are GCC/Clang-specific. The `#if defined(__BYTE_ORDER__)
&& (__BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__)` check compiles **to
the byte-loop fallback** on every other compiler (MSVC, older
toolchains). On a BE host without those macros the code is correct.
Severity: **low** — degrades gracefully.

**bench.c:139–140 — `aligned_alloc`**:
This is a **C11** function, not C99. The Makefile compiles everything
with `-std=c99`, but bench.c defines `_ISOC11_SOURCE` *before*
including any header. On glibc ≥ 2.10 this exposes `aligned_alloc`
even in `-std=c99` mode. On other libcs (musl, MSVC) this may fail
silently or warn. Severity: **low** (test/bench code, not library).

**bench.c:31, 44 — POSIX features**:
`clock_gettime`, `sched_setaffinity`, `cpu_set_t`, `CPU_ZERO`,
`CPU_SET`. Wrapped in `_POSIX_C_SOURCE 200809L` and `_GNU_SOURCE` so
they're visible on Linux/glibc. The full set is reachable via
`_GNU_SOURCE`. Severity: **low** (test/bench only).

**kat_test.c:26 — `strcasecmp`**:
POSIX / BSD 4.3, not C99. The test driver compiles only on POSIX-ish
hosts. Severity: **low** (test only).

**kat_test.c:27, 75–77 — `isspace` cast to `(unsigned char)`**:
This is the **correct** idiom for `ctype.h` functions, which take
`int` but undefined on negative `char` values. C99-mandated. OK.

**kat_test.c:28 — `<errno.h>`**:
Included but never used. Severity: **trivial** cleanup.

**vpaes.h:4 — typo "Implementaes"**:
Cosmetic. Severity: **trivial**.

### 2.3 Pure-C99 features used correctly

The following C99 features are used and **all correct**:

| Feature                         | Location              | OK? |
|---------------------------------|-----------------------|-----|
| `static inline`                 | vpaes.c:221, 230, 254, 285, 302, 320, 335 | ✓ |
| Designated initializers         | vpaes.c:485–495 (`[10] = enc_128`)         | ✓ |
| `//` line comments              | gen_tables.c, bench.c, vpaes.c sparse use  | ✓ |
| `<stdint.h>` fixed-width types  | everywhere                                  | ✓ |
| `<stdbool.h>`                   | not used (good — keep to C89 subset)        | ✓ |
| Mixed decls & code              | vpaes.c:174, 230, 254                       | ✓ |
| `for (int i = ...)` loop var    | everywhere                                  | ✓ |

---

## 3. Common C bugs

### 3.1 Buffer / array bounds

**`set_key_impl` — `Rcon` index** (vpaes.c:160):
```c
if ((i % (nk / 4)) == 0)
    temp = sub_word(rot_word(temp)) ^ ((uint32_t)Rcon[i / (nk / 4)] << 24);
```
`Rcon` has 15 entries (indices 0–14). Max index reached:
* AES-128 (nk=16, nk/4=4): i/4 reaches max when i=43 (= total/4 - 1 = 43); max `i/4` = 10.
* AES-192 (nk=24, nk/4=6): i up to 51; max `i/6` = 8.
* AES-256 (nk=32, nk/4=8): i up to 59; max `i/8` = 7.

All three are within `[0, 14]`. **No out-of-bounds**. Rcon[0] is
never accessed because the loop's `i < nk/4` "first block copy"
precedes the Rcon branch.

**`enc_round` / `dec_round` / `enc_last` / `dec_last`** — table index:
```c
Te0[(s0 >> 24) & 0xff] ^ Te1[(s1 >> 16) & 0xff] ^ ...
```
The `& 0xff` mask was added in an earlier fix to bound table lookups
to `[0, 255]`. Without it, indices could reach ~16384 (mask is 0x4050
on a typical round). **Currently safe**.

**`enc_dispatch` / `dec_dispatch`** — sparse array:
The arrays are size 16 with designated initializers at indices 10, 12,
14. `set_key_impl` returns nr ∈ {10, 12, 14}. `enc_dispatch[nr]` is
always in-range. **Safe**.

### 3.2 Type narrowing & implicit conversions

**vpaes_set_key:179** — `(int)key_len`:
`key_len` is constrained to {16, 24, 32} by the check above; all fit
in `int` with no sign issue. **Safe**.

**vpaes.c:601–604** — `((uint32_t)ctr[12] << 24)`:
`ctr[i]` is `uint8_t`. Cast to `uint32_t` then shift. C99 integer
promotion makes the shift well-defined; cast back to `uint8_t` on
store (lines 606–609) is correct. **Safe**.

**bench.c:33** — `BUF_BYTES = (1u << 20)`:
`unsigned int` literal. Used as `size_t` everywhere; implicit
conversion widens. **Safe**.

**bench.c:139–140** — `aligned_alloc(64, BUF_BYTES + 64)`:
C11 `aligned_alloc` requires size to be a multiple of alignment.
`BUF_BYTES + 64 = 1048640`; `1048640 % 64 = 0`. **Safe**.

### 3.3 Integer promotion in `xtime` / `gmul`

**gen_tables.c:65** — `xtime`:
```c
return (uint8_t)((x << 1) ^ (((x >> 7) & 1) * 0x1b));
```
`x` is `uint8_t`. C99 integer promotion converts to `int` before the
shift. `x << 1` for x ∈ [128, 255] gives values up to 510, all within
`int`. `((x >> 7) & 1)` is 0 or 1; `* 0x1b` is 0 or 27. XOR result is
≤ 511; cast back to `uint8_t` truncates to lower 8 bits, which is the
correct GF(2^8) doubling. **Correct**, but easy to misread — adding a
parenthesised comment would help.

**vpaes.c:92–103** — `gmul`:
Same promotion behaviour. `a <<= 1` on `uint8_t` is on the promoted
`int`, truncated on assignment. **Correct**.

### 3.4 Strict aliasing

**vpaes.c:233–234, 263–264** — unaligned 64-bit loads/stores via cast:
```c
uint64_t lo = *(const uint64_t *)(const void *)&in[0];
...
*(uint64_t *)(void *)&out[0] = lo;
```

Per C99 §6.5p7 (the "strict aliasing rule"), an object may be accessed
only through an lvalue of:
* its effective type,
* a qualified version of that,
* a signed/unsigned variant,
* a character type (`char`, `unsigned char`),
* an aggregate or union containing the above.

Reading 16 `uint8_t` values through a `uint64_t *` violates this rule
*technically*. In practice GCC and Clang allow it on every
architecture that supports unaligned loads (x86-64, ARMv7+, LA664),
but a strictly-conforming compiler is permitted to assume the pointer
does not alias and emit broken code.

**Severity**: **medium** for portable C. Mitigations: copy via
`memcpy` (always well-defined), or use `__attribute__((__may_alias__))`
on the aliasing pointer type. The current code is correct on every
compiler anyone is likely to use, but technically not strict-aliasing
clean. Same applies to `bench.c` (no 64-bit aliasing there).

### 3.5 CTR counter overflow (security, not correctness)

**vpaes.c:588–610** — `vpaes_ctr_xcrypt`:
The counter is incremented as a 32-bit big-endian integer in
`ctr[12..15]`. After 2^32 blocks (= 64 GiB at 16 B/block), `c++`
wraps to 0 and the keystream repeats. RFC 3686 mandates this
behaviour (the upper 96 bits of the IV are fixed, only the lower 32
counter changes), but **callers must enforce a per-IV cap < 2^32
blocks**. The implementation does not enforce this; it is the caller's
responsibility. No upper bound is checked. Severity: **by design**,
but worth documenting in the header. **Recommendation** (not a fix
— analysis only): add a comment to `vpaes_ctr_xcrypt` in `vpaes.h`
warning that input length must be < 2^32 blocks per IV.

### 3.6 Sign / unsigned pitfalls

**No signed/unsigned comparison bugs found.** All bit-shift
expressions use `uint32_t` or `uint8_t` operands; the `& 0xff` masks
make every intermediate positive within the unsigned type.

### 3.7 Null-pointer / uninitialised-memory checks

**vpaes_set_key:176** — guards `!ctx || !key`. Good.

**`vpaes_ctx` struct** — fields initialised by `set_key_impl` (writes
all of `rk[]`) and the `rk_inv` loop (writes all of `rk_inv[]`) and
explicit assignments of `nrounds`, `enc_dispatch`, `dec_dispatch`. No
uninitialised fields. Good.

**`bench_blk` / `bench_mode` static buffers** — `in[16]`, `out[16]`,
`key[32]` initialised by explicit loops. `aligned_alloc` returns
uninitialised memory but is filled by the deterministic-fill loop on
lines 142–143. Good.

### 3.8 Loop boundary correctness

**vpaes.c:533 — ECB while loop**: `while (len >= VPAES_BLOCKLEN)`.
Handles `len` not divisible by 16 silently (truncates to multiple of
16). Same for CBC. CTR does handle partial blocks (line 597–598).
**Behaviour is documented / sensible** — the API says "no padding,
multiple of 16 bytes required", and the silent truncation matches
that.

**vpaes.c:559 — CBC encrypt while**: same pattern. The XOR loop
(line 561) processes exactly 16 bytes, so this is consistent.

### 3.9 Concurrency / thread-safety

**`kat_test.c:205–206`** — non-const globals `g_mode_is_cbc`,
`g_mode_is_ctr`: written once at startup, read concurrently with
itself only. Safe for a single-threaded test driver.

**`vpaes_ctx`** — contains a function pointer and pre-computed tables.
Two threads encrypting with the *same* context are safe (read-only).
Two threads *mutating* the same context (`vpaes_set_key` while
another runs `vpaes_encrypt_block`) is **not** safe — but this is
universal for crypto APIs and not a bug.

### 3.10 Dead code / minor cleanups

| Item                                                | Location            | Severity |
|-----------------------------------------------------|---------------------|----------|
| `isbox_unused[256]` table (duplicated in gen_tables)| vpaes.c:69–86       | trivial  |
| `<errno.h>` unused include                         | kat_test.c:28       | trivial  |
| Comment typo "Implementaes"                         | vpaes.h:4           | trivial  |

---

## 4. Summary scorecard

| Audit dimension                  | Result |
|----------------------------------|--------|
| Functional correctness            | PASS — 5/5 sanity + 48/48 KAT (4156/4156) |
| Endianness correctness            | PASS — works on LE; falls back safely on BE  |
| C99 strict compliance             | MOSTLY — relies on 5 GCC/Clang extensions (all gracefully degrading or guarded) |
| Common C bugs                     | MOSTLY — one strict-aliasing concern in LE fast path; one CTR overflow caveat (by design) |
| Buffer overflow / OOB             | NONE — all table & Rcon accesses in bounds   |
| Type narrowing                    | NONE — `(int)key_len` is safe due to pre-check |
| Integer overflow / UB             | NONE — GF(2^8) arithmetic uses masking correctly |
| Null / uninit deref               | NONE — vpaes_set_key guards ctx/key          |
| Thread-safety                     | Read-only ctx use is safe; concurrent key-set is not (universal) |

---

## 5. Findings the user asked about, ranked by impact

### High-impact (review-only, do not edit without a fix plan)

1. **Strict aliasing on LE 64-bit loads/stores** (vpaes.c:233–234, 263–264).
   Not a bug on GCC/Clang/x86-64/LA664, but not strictly conforming C99.
   For the stated goal of producing a portable pure-C reference, `memcpy`
   would be cleaner. Severity: medium-low for *this* codebase (the
   audit target is a NIST KAT-validated implementation, where binary
   reproducibility on the test platform is what matters).

2. **CTR counter wraparound** (vpaes.c:605) — by-design but undocumented
   in the header. Callers must enforce < 2^32 blocks per IV. Severity:
   low (test vectors are tiny), but a real-world hazard.

### Medium-impact

3. **`isbox_unused` dead array** (vpaes.c:69) — wastes 256 bytes of
   `.rodata` and depends on `__attribute__((unused))`. Drop it (the
   runtime decryption path uses `TD0d..TD3d` from `vpaes_tables.inc`).

4. **Compiler-extension dependency** (vpaes.c:222, 232, 238, 256) —
   `__builtin_bswap32/64` and `__BYTE_ORDER__` macros. Falls back
   correctly on other compilers via `#else` branches, but the
   `bytes_to_state`/`state_to_bytes` fallback is byte-by-byte, which
   is what would run on a non-GCC/non-Clang BE host (rare in 2026,
   but real on some embedded toolchains). Severity: low.

### Low-impact / cosmetic

5. Comment typo "Implementaes" → "Implements" (vpaes.h:4).
6. Unused `#include <errno.h>` (kat_test.c:28).
7. `bench.c` mixes `-std=c99` (Makefile) with C11 `aligned_alloc` —
   works on glibc 2.10+ but is technically inconsistent. Test/bench
   code, not library.
8. `Makefile` uses GNU-make-only features (`?=`, `|`, `$$var`).
   Not a C issue; documented for completeness.

---

## 6. What was *not* flagged (intentional design)

* **3-round substitution constant tables** — pure data, no logic, no
  bug surface.
* **Phase 2.2 dispatch tables** — sparse, in-range access, with
  `extern` declarations matched by file-scope definitions.
* **The duplicated `dec_last` logic inside `dec_128/192/256`** — was a
  bug source in an earlier revision; the current copies are byte-for-byte
  identical to the function they inline and have been kept in sync by
  the earlier `replace_all` pass.
* **FIPS-197 / NIST KAT correctness** — covered exhaustively by the
  4156-vector NIST CAVP run; not the topic of *this* audit.

---

## 7. Conclusion

The implementation is **functionally correct** (NIST-validated), **safe
on the tested LE host** (x86-64 / LoongArch LA664), and uses only a
small, well-isolated set of compiler extensions — each with a working
fallback. The two real findings worth noting are:

1. The LE fast path uses non-strict-aliasing 64-bit reads/writes. Fine
   on every modern compiler that anyone is likely to use, but a strictly
   portable C99 build would route this through `memcpy` instead.
2. `vpaes_ctr_xcrypt` does not bound its input length per IV. Callers
   must enforce < 2^32 blocks; the header does not say so.

Neither affects the correctness tests that have been run (the KAT
vectors are < 100 blocks each), and neither is an "implementation
defect" — they are portability / documentation notes. **The code is
production-grade for the KAT-validated use cases.**