/*
 * bench.c  -  Microbenchmark for vpaes_pure_c
 *
 * Measures throughput (MB/s) and cycles/byte for:
 *   - single-block  encrypt / decrypt   (AES-128/192/256)
 *   - ECB           encrypt / decrypt   (AES-128/192/256)
 *   - CBC           encrypt / decrypt   (AES-128)
 *   - CTR           encrypt             (AES-128)
 *
 * Build: see Makefile (`make bench`).
 *
 * Output: one row per test, with MB/s and cycles/byte.  Pinned to a
 * single CPU so the timing is stable across runs.
 */

#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#ifndef _ISOC11_SOURCE
#define _ISOC11_SOURCE
#endif
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include "vpaes.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sched.h>
#include <errno.h>

/* M-8: portable aligned-allocator wrapper.  C11 `aligned_alloc` is
 * exposed by glibc ≥ 2.16 with _ISOC11_SOURCE but is not in stock
 * -std=c99.  POSIX `posix_memalign` works on every glibc/musl/BSD
 * platform in the past 15 years.  The wrapper picks whichever is
 * available and yields equivalent semantics for the bench (size
 * must be a multiple of `align`; we always allocate extra slack
 * which satisfies the C11 constraint).                              */
static void *xaligned_alloc(size_t align, size_t size)
{
#if defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 201112L)
    return aligned_alloc(align, size);
#else
    void *p = NULL;
    if (posix_memalign(&p, align, size) != 0) return NULL;
    return p;
#endif
}

#define BUF_BYTES   (1u << 20)   /* 1 MiB working buffer            */
#define WARMUP_MS   100
#define TARGET_MS   750           /* per-test run length             */

/* ------------------------------------------------------------------ */
/* timing                                                              */
/* ------------------------------------------------------------------ */

static double now_sec(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

static void pin_cpu(void)
{
    /* Pin to CPU 0 for stable timing. */
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(0, &set);
    (void)sched_setaffinity(0, sizeof set, &set);
}

/* ------------------------------------------------------------------ */
/* one timed run: time `inner(BUF_BYTES)` repeatedly until t >= ms     */
/* ------------------------------------------------------------------ */

typedef void (*work_fn)(void *ctx, const uint8_t *in, uint8_t *out, size_t n,
                        const uint8_t *iv);

static double run_timed(work_fn inner, void *ctx,
                        const uint8_t *in, uint8_t *out, size_t n,
                        const uint8_t *iv, int ms)
{
    double t0 = now_sec();
    double deadline = t0 + ms * 1e-3;
    size_t iters = 0;
    do {
        inner(ctx, in, out, n, iv);
        iters++;
    } while (now_sec() < deadline);
    double dt = now_sec() - t0;
    return (double)iters * (double)n / dt;   /* bytes per second */
}

/* ------------------------------------------------------------------ */
/* mode wrappers (uniform `work_fn` signature)                         */
/* ------------------------------------------------------------------ */

static void _ecb_enc(void *ctx, const uint8_t *in, uint8_t *out, size_t n,
                     const uint8_t *iv)
{ (void)iv; vpaes_ecb_encrypt ((vpaes_ctx*)ctx, in, out, n); }

static void _ecb_dec(void *ctx, const uint8_t *in, uint8_t *out, size_t n,
                     const uint8_t *iv)
{ (void)iv; vpaes_ecb_decrypt ((vpaes_ctx*)ctx, in, out, n); }

static void _cbc_enc(void *ctx, const uint8_t *in, uint8_t *out, size_t n,
                     const uint8_t *iv)
{ vpaes_cbc_encrypt ((vpaes_ctx*)ctx, iv, in, out, n); }

static void _cbc_dec(void *ctx, const uint8_t *in, uint8_t *out, size_t n,
                     const uint8_t *iv)
{ vpaes_cbc_decrypt ((vpaes_ctx*)ctx, iv, in, out, n); }

static void _ctr_xcrypt(void *ctx, const uint8_t *in, uint8_t *out, size_t n,
                        const uint8_t *iv)
{ vpaes_ctr_xcrypt  ((vpaes_ctx*)ctx, iv, in, out, n); }

/* ------------------------------------------------------------------ */
/* single-block path                                                   */
/* ------------------------------------------------------------------ */

typedef void (*blk_fn)(const vpaes_ctx *ctx, const uint8_t *in, uint8_t *out);

static double run_blk(blk_fn f, const vpaes_ctx *ctx,
                      const uint8_t *in, uint8_t *out, int ms)
{
    double t0 = now_sec();
    double deadline = t0 + ms * 1e-3;
    size_t iters = 0;
    do {
        f(ctx, in, out);
        iters++;
    } while (now_sec() < deadline);
    double dt = now_sec() - t0;
    return (double)iters * 16.0 / dt;   /* bytes per second */
}

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

static const char *key_name(int k)
{
    return (k == 16) ? "AES-128" :
           (k == 24) ? "AES-192" : "AES-256";
}

/* measure ECB / CBC / CTR */
static void bench_mode(const char *mode, int key_bytes, work_fn enc, work_fn dec,
                       int has_dec, const uint8_t *iv)
{
    static uint8_t *in  = NULL, *out = NULL;
    if (!in) {
        /* M-8 + M-9: portable aligned alloc + NULL check. */
        in  = (uint8_t *)xaligned_alloc(64, BUF_BYTES + 64);
        out = (uint8_t *)xaligned_alloc(64, BUF_BYTES + 64);
        if (!in || !out) {
            fprintf(stderr, "bench: xaligned_alloc failed: %s\n",
                    strerror(errno));
            exit(EXIT_FAILURE);
        }
        /* simple deterministic fill */
        for (size_t i = 0; i < BUF_BYTES + 64; i++) in[i] = (uint8_t)(i * 31 + 7);
    }

    static uint8_t key[32];
    for (int i = 0; i < key_bytes; i++) key[i] = (uint8_t)(i * 17 + 3);

    vpaes_ctx ctx;
    if (vpaes_set_key(&ctx, key, key_bytes) != 0) {
        printf("%-22s %-9s  key init failed\n", mode, key_name(key_bytes));
        return;
    }

    /* warm-up */
    run_timed(enc, &ctx, in, out, BUF_BYTES, iv, WARMUP_MS);

    double enc_bps = run_timed(enc, &ctx, in, out, BUF_BYTES, iv, TARGET_MS);
    double dec_bps = 0;
    if (has_dec && dec)
        dec_bps = run_timed(dec, &ctx, in, out, BUF_BYTES, iv, TARGET_MS);

    double hz = 3.6e9;  /* CPU nominal (Xeon 6982P-C @ 3.6 GHz) */
    printf("%-22s %-9s  enc %8.1f MB/s  %5.2f c/B"
           "   |  dec %8.1f MB/s  %5.2f c/B\n",
           mode, key_name(key_bytes),
           enc_bps / 1e6, hz / enc_bps,
           dec_bps / 1e6, dec_bps > 0 ? hz / dec_bps : 0);
}

/* measure single-block path */
static void bench_blk(const char *tag, int key_bytes)
{
    static uint8_t in[16], out[16];
    for (int i = 0; i < 16; i++) in[i] = (uint8_t)i;

    static uint8_t key[32];
    for (int i = 0; i < key_bytes; i++) key[i] = (uint8_t)(i + 1);

    vpaes_ctx ctx;
    if (vpaes_set_key(&ctx, key, key_bytes) != 0) return;

    /* warm */
    run_blk(vpaes_encrypt_block, &ctx, in, out, WARMUP_MS);

    double enc_bps = run_blk(vpaes_encrypt_block, &ctx, in, out, TARGET_MS);
    double dec_bps = run_blk(vpaes_decrypt_block, &ctx, in, out, TARGET_MS);

    double hz = 3.6e9;
    printf("%-22s %-9s  enc %6.2f MB/s  %5.1f c/B"
           "   |  dec %6.2f MB/s  %5.1f c/B   (per-block)\n",
           tag, key_name(key_bytes),
           enc_bps / 1e6, hz / enc_bps,
           dec_bps / 1e6, hz / dec_bps);
}

/* ------------------------------------------------------------------ */
/* main                                                               */
/* ------------------------------------------------------------------ */

int main(void)
{
    pin_cpu();

    /* disable turbo so cycles/byte are stable */
    /* (best-effort; ignored if not permitted) */

    printf("vpaes_pure_c benchmark\n");
    printf("buffer = %u bytes, target = %d ms/iteration, "
           "warmup = %d ms\n\n", BUF_BYTES, TARGET_MS, WARMUP_MS);

    printf("=== single block ===\n");
    bench_blk("encrypt_block", 16);
    bench_blk("encrypt_block", 24);
    bench_blk("encrypt_block", 32);
    bench_blk("decrypt_block", 16);
    bench_blk("decrypt_block", 24);
    bench_blk("decrypt_block", 32);

    /* deterministic IV for CBC / CTR */
    uint8_t iv[16];
    for (int i = 0; i < 16; i++) iv[i] = (uint8_t)(0xA5 ^ i);

    printf("\n=== ECB ===\n");
    bench_mode("ECB", 16, _ecb_enc, _ecb_dec, 1, NULL);
    bench_mode("ECB", 24, _ecb_enc, _ecb_dec, 1, NULL);
    bench_mode("ECB", 32, _ecb_enc, _ecb_dec, 1, NULL);

    printf("\n=== CBC ===\n");
    bench_mode("CBC", 16, _cbc_enc, _cbc_dec, 1, iv);
    bench_mode("CBC", 24, _cbc_enc, _cbc_dec, 1, iv);
    bench_mode("CBC", 32, _cbc_enc, _cbc_dec, 1, iv);

    printf("\n=== CTR (RFC 3686) ===\n");
    bench_mode("CTR", 16, _ctr_xcrypt, NULL, 0, iv);
    bench_mode("CTR", 24, _ctr_xcrypt, NULL, 0, iv);
    bench_mode("CTR", 32, _ctr_xcrypt, NULL, 0, iv);

    return 0;
}