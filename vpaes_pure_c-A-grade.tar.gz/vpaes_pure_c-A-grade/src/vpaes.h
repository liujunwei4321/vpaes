/*
 * vpaes.h  -  Portable pure-C AES-128/192/256 implementation
 *
 * Implements the vpaes concept (table-based AES with fused
 * SubBytes/MixColumns) using only standard C99 — NO SIMD intrinsics,
 * NO platform-specific headers.  Algorithmically equivalent to the
 * scalar fall-back of Mike Hamburg's "Vector Permute AES" (CHES 2009),
 * but written from scratch as an independent portable implementation.
 *
 * Public-domain.
 *
 * ===================================================================
 * API preconditions (caller must satisfy; not enforced at runtime):
 * ===================================================================
 *
 *   - ctx != NULL for every function taking vpaes_ctx*.
 *   - All buffers point to at least VPAES_BLOCKLEN (16) bytes.
 *   - Aliasing rules:
 *       * in == out                              : ALWAYS SAFE.
 *       * in != out, no overlap                  : ALWAYS SAFE.
 *       * partial overlap (e.g. out == in + 1)    : UNDEFINED (use
 *                                                 disjoint or fully
 *                                                 aliased buffers).
 *   - For multi-block functions (ECB/CBC/CTR):
 *       * ECB and CBC : len must be a multiple of VPAES_BLOCKLEN;
 *                        trailing partial blocks are silently dropped.
 *       * CTR         : len may be any size; only the trailing partial
 *                        block uses fewer than 16 keystream bytes.
 *                        This implementation ENFORCES the
 *                        < 2^32 blocks per IV constraint and refuses
 *                        silently to encrypt beyond the wraparound.
 *                        For longer streams the caller must chunk and
 *                        bump the upper 96 bits of the IV manually.
 *       * CBC encrypt and CBC decrypt both work correctly in-place
 *         (in == out) since r1.5.
 *   - The context must have been initialised by vpaes_set_key before
 *     any encrypt/decrypt call.  Re-initialisation with the same
 *     context is allowed (the prior round keys are securely zeroed
 *     before the new key material is written).
 *   - Concurrent encrypt/decrypt calls on the same context from
 *     multiple threads are NOT supported (read-only ctx use across
 *     threads IS safe).
 *
 * ===================================================================
 * Security warning (NIST-style):
 * ===================================================================
 *   This implementation is NOT constant-time.  T-table lookups leak
 *   cache-line access patterns; an attacker with prime+probe access
 *   on the same physical core may recover the round key.  Do NOT use
 *   this code in environments where side-channel resistance is
 *   required (shared cloud VMs, smart cards, HSMs).  Pair with an
 *   authenticated mode (HMAC-SHA-256, GMAC) and use a unique fresh
 *   IV/nonce per (key, message) pair; CTR nonce reuse leaks the XOR
 *   of the two plaintexts.
 *
 * ===================================================================
 * Conformance:
 * ===================================================================
 *   Requires a HOSTED C99 environment that provides <stdint.h> and
 *   <stddef.h>.  Tested with gcc 7+ and clang 10+ on x86-64 and
 *   LoongArch64.  NOT suitable for strict freestanding targets that
 *   lack <stdint.h>.
 */

#ifndef VPAES_H
#define VPAES_H

/* H-2: hosted-C99 + <stdint.h> availability guard.  Guard against
 * freestanding environments that lack <stdint.h>.  Documented in the
 * file preamble.  The check is intentionally advisory (yields a
 * diagnostic, not a hard error) so users running with -Werror can
 * still consume the header after defining the macro. */
#if defined(__STDC_HOSTED__) && (__STDC_HOSTED__ == 0)
#  if defined(__has_include)
#    if !__has_include(<stdint.h>)
#      warning "vpaes.h: freestanding C without <stdint.h> is unsupported"
#    endif
#  endif
#endif

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define VPAES_BLOCKLEN   16      /* AES block size (bytes)                */
#define VPAES_KEY_128    16
#define VPAES_KEY_192    24
#define VPAES_KEY_256    32

/* Number of expanded-key words. */
#define VPAES_Nr_128     10
#define VPAES_Nr_192     12
#define VPAES_Nr_256     14
#define VPAES_EXP_WORDS  60      /* 15 round-keys × 4 words — covers AES-256 */

/* Internal type for round-function dispatch pointers (Phase 2.2).
 * The encrypt function takes the state and the round-key base pointer;
 * the decrypt function additionally takes the modified decryption key.
 * These pointers are bound by vpaes_set_key() so that subsequent block
 * calls invoke a fully-unrolled specialised routine directly.            */
typedef void (*vpaes_encrypt_fn)(uint32_t s[4], const uint32_t *rk);
typedef void (*vpaes_decrypt_fn)(uint32_t s[4], const uint32_t *rk,
                                 const uint32_t *rki);

typedef struct {
    uint32_t rk[VPAES_EXP_WORDS];     /* expanded key (Nk words per round) */
    int      nrounds;                 /* 10 / 12 / 14                       */
    uint32_t rk_inv[VPAES_EXP_WORDS]; /* modified decryption key: for
                                       * round r in [1, nrounds-1],
                                       * rk_inv[r] = InvMixColumns(rk[r]).
                                       * Used by Td-table decryption.      */
    vpaes_encrypt_fn enc_dispatch;    /* bound at vpaes_set_key; Phase 2.2 */
    vpaes_decrypt_fn dec_dispatch;    /* bound at vpaes_set_key; Phase 2.2 */
} vpaes_ctx;

/* ---- key schedule ----                                              */
int  vpaes_set_key(vpaes_ctx *ctx, const uint8_t *key, size_t key_len);

/* ---- single-block ECB ----                                          */
void vpaes_encrypt_block(const vpaes_ctx *ctx,
                         const uint8_t in[VPAES_BLOCKLEN],
                         uint8_t       out[VPAES_BLOCKLEN]);

void vpaes_decrypt_block(const vpaes_ctx *ctx,
                         const uint8_t in[VPAES_BLOCKLEN],
                         uint8_t       out[VPAES_BLOCKLEN]);

/* ---- mode helpers (no padding, multiple of 16 bytes required) ----   */
void vpaes_ecb_encrypt(const vpaes_ctx *ctx,
                       const uint8_t *in, uint8_t *out, size_t len);

void vpaes_ecb_decrypt(const vpaes_ctx *ctx,
                       const uint8_t *in, uint8_t *out, size_t len);

void vpaes_cbc_encrypt(const vpaes_ctx *ctx, const uint8_t iv[VPAES_BLOCKLEN],
                       const uint8_t *in, uint8_t *out, size_t len);

void vpaes_cbc_decrypt(const vpaes_ctx *ctx, const uint8_t iv[VPAES_BLOCKLEN],
                       const uint8_t *in, uint8_t *out, size_t len);

void vpaes_ctr_xcrypt(const vpaes_ctx *ctx, const uint8_t iv[VPAES_BLOCKLEN],
                      const uint8_t *in, uint8_t *out, size_t len);

#ifdef __cplusplus
}
#endif

#endif /* VPAES_H */
