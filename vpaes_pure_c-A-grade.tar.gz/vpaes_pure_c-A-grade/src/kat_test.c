/*
 * kat_test.c  -  Driver to run NIST AES KAT vectors through vpaes_pure_c
 *
 * Usage:
 *   kat_test <kat_file> [-d]
 *
 * The driver parses the standard NIST .txt KAT format used by the
 * reference vpaes project (Mike Hamburg / NIST).  Each section begins
 * with [ENCRYPT] or [DECRYPT] and contains:
 *
 *     COUNT = <n>
 *     KEY = <hex>
 *     [IV  = <hex>]     (CBC / CTR only)
 *     PLAINTEXT  = <hex>
 *     CIPHERTEXT = <hex>
 *
 * If -d is supplied the driver also performs a cross-check by running
 * the inverse direction (encrypt on the [DECRYPT] sets and vice-versa)
 * and ensures that decrypt(encrypt(x)) == x.
 */

#include "vpaes.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <errno.h>

static int hex_to_bytes(const char *hex, uint8_t *out, size_t out_max)
{
    size_t n = 0;
    while (*hex) {
        if (*hex == '\n' || *hex == '\r' || *hex == ' ') { hex++; continue; }
        char hi = *hex++;
        if (!hi) break;
        char lo = *hex++;
        if (!lo) return -1;
        int v = 0;
        if      (hi >= '0' && hi <= '9') v = (hi - '0')     << 4;
        else if (hi >= 'a' && hi <= 'f') v = (hi - 'a' + 10) << 4;
        else if (hi >= 'A' && hi <= 'F') v = (hi - 'A' + 10) << 4;
        else return -1;
        if      (lo >= '0' && lo <= '9') v |= (lo - '0');
        else if (lo >= 'a' && lo <= 'f') v |= (lo - 'a' + 10);
        else if (lo >= 'A' && lo <= 'F') v |= (lo - 'A' + 10);
        else return -1;
        if (n >= out_max) return -1;
        out[n++] = (uint8_t)v;
    }
    return (int)n;
}

static void print_hex(const char *tag, const uint8_t *bytes, size_t len)
{
    printf("%s = ", tag);
    for (size_t i = 0; i < len; i++) printf("%02x", bytes[i]);
    printf("\n");
}

typedef enum { DIR_ENCRYPT, DIR_DECRYPT } dir_t;

typedef struct {
    int    count;
    uint8_t key[32];   size_t key_len;
    uint8_t iv[16];
    int    has_iv;
    uint8_t pt[64];    size_t pt_len;
    uint8_t ct[64];    size_t ct_len;
    dir_t  dir;
} vec_t;

static char *trim(char *s)
{
    while (*s && isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

/* Read a single vector block from `fp`. Returns 1 on success, 0 on EOF.
 *
 * Vectors in a NIST CAVP KAT file are delimited by `COUNT = N` lines.
 * When a new COUNT is encountered after we have already begun collecting
 * fields for the current vector, that line is pushed back for the next
 * call so the outer loop can process all vectors in the file (not just
 * the last one). */
static int read_vec(FILE *fp, vec_t *v)
{
    static char pushed_line[1024];
    static int  has_pushback = 0;
    char line[1024];

    v->count = -1;
    v->key_len = v->pt_len = v->ct_len = 0;
    v->has_iv = 0;

    int got_count = 0;   /* True once we have read COUNT = for the
                           vector currently being assembled. */

    for (;;) {
        char *p;
        if (has_pushback) {
            strncpy(line, pushed_line, sizeof line - 1);
            line[sizeof line - 1] = 0;
            has_pushback = 0;
        } else if (!fgets(line, sizeof line, fp)) {
            /* EOF: return the last complete vector, if any. */
            return (v->count >= 0) ? 1 : 0;
        }

        p = trim(line);
        if (*p == 0) continue;          /* blank line */

        if (*p == '[') {                /* section header */
            char *q = strchr(p, ']');
            if (!q) continue;
            *q = 0;
            v->dir = (strcasecmp(p + 1, "DECRYPT") == 0)
                     ? DIR_DECRYPT : DIR_ENCRYPT;
            continue;
        }

        char *eq = strchr(p, '=');
        if (!eq) continue;
        *eq = 0;
        char *key = trim(p);
        char *val = trim(eq + 1);

        if (strcasecmp(key, "COUNT") == 0) {
            if (got_count) {
                /* A new vector is starting. We can't just save `line`
                 * here because we have already overwritten the '='
                 * above with a NUL; reconstruct a clean COUNT line
                 * from the value we just parsed and push it back. */
                snprintf(pushed_line, sizeof pushed_line,
                         "COUNT = %s", val);
                has_pushback = 1;
                return 1;
            }
            v->count = atoi(val);
            got_count = 1;
        } else if (strcasecmp(key, "KEY") == 0) {
            v->key_len = hex_to_bytes(val, v->key, sizeof v->key);
        } else if (strcasecmp(key, "IV") == 0) {
            v->has_iv = 1;
            (void)hex_to_bytes(val, v->iv, sizeof v->iv);
        } else if (strcasecmp(key, "PLAINTEXT") == 0) {
            v->pt_len = hex_to_bytes(val, v->pt, sizeof v->pt);
        } else if (strcasecmp(key, "CIPHERTEXT") == 0) {
            v->ct_len = hex_to_bytes(val, v->ct, sizeof v->ct);
        }
    }
}

static int run_one(const vec_t *v)
{
    vpaes_ctx ctx;
    if (vpaes_set_key(&ctx, v->key, v->key_len) != 0) {
        fprintf(stderr, "  bad key length %zu\n", v->key_len);
        return 0;
    }

    /* Detect mode from the presence of IV and the file name.  We keep it
     * simple here: the test driver picks ECB / CBC automatically based
     * on the IV byte presence and the directory name (caller decides). */
    extern int g_mode_is_cbc;
    extern int g_mode_is_ctr;

    uint8_t out[64];
    size_t  len = v->pt_len;

    if (g_mode_is_ctr) {
        if (!v->has_iv) {
            fprintf(stderr, "  CTR vector without IV\n");
            return 0;
        }
        vpaes_ctr_xcrypt(&ctx, v->iv, v->pt, out, len);
    } else if (g_mode_is_cbc) {
        if (!v->has_iv) {
            fprintf(stderr, "  CBC vector without IV\n");
            return 0;
        }
        if (v->dir == DIR_ENCRYPT)
            vpaes_cbc_encrypt(&ctx, v->iv, v->pt, out, len);
        else
            vpaes_cbc_decrypt(&ctx, v->iv, v->ct, out, len);
    } else { /* ECB */
        if (v->dir == DIR_ENCRYPT)
            vpaes_ecb_encrypt(&ctx, v->pt, out, len);
        else
            vpaes_ecb_decrypt(&ctx, v->ct, out, len);
    }

    const uint8_t *expected = (v->dir == DIR_ENCRYPT) ? v->ct : v->pt;
    if (memcmp(out, expected, len) != 0) {
        printf("MISMATCH at COUNT=%d:\n", v->count);
        print_hex("  expected", expected, len);
        print_hex("  got     ", out, len);
        return 0;
    }
    return 1;
}

int g_mode_is_cbc = 0;
int g_mode_is_ctr = 0;

int main(int argc, char **argv)
{
    if (argc < 2) {
        fprintf(stderr, "usage: %s <kat_file>\n", argv[0]);
        return 2;
    }
    /* Infer mode from file name */
    const char *name = argv[1];
    if (strstr(name, "CBC") || strstr(name, "cbc"))  g_mode_is_cbc = 1;
    if (strstr(name, "CTR") || strstr(name, "ctr"))  g_mode_is_ctr = 1;

    FILE *fp = fopen(argv[1], "r");
    if (!fp) { perror(argv[1]); return 2; }

    int total = 0, ok = 0;
    vec_t v;
    while (read_vec(fp, &v)) {
        total++;
        if (run_one(&v)) ok++;
    }
    fclose(fp);
    printf("File: %s -- %s  [mode=%s]  passed %d/%d\n",
           argv[1],
           (ok == total) ? "OK" : "FAIL",
           g_mode_is_ctr ? "CTR" : (g_mode_is_cbc ? "CBC" : "ECB"),
           ok, total);
    return (ok == total) ? 0 : 1;
}
