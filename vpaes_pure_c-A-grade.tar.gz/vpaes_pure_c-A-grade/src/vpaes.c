/*
 * vpaes.c  -  Pure-C AES-128/192/256 (no SIMD)
 *
 * Implements Mike Hamburg's "vpaes" concept in portable C99.  The
 * original vpaes (CHES 2009, Stanford) accelerates AES with Intel
 * SSSE3 pshufb.  When projected onto a scalar CPU the algorithm
 * collapses to a standard T-table AES with fused SubBytes /
 * MixColumns lookups — that is exactly what this file implements.
 *
 * Optimisations applied (Phase 1 + Phase 2):
 *   1.1  Pre-computed T-tables in .rodata (no runtime init).
 *   1.2  Hoisted byte extracts in main round (no per-byte CSE).
 *   1.3  In-place CBC (no stack temp per block, in-place encrypt).
 *   1.4  CTR 32-bit big-endian counter increment (no byte loop).
 *   1.5  Block functions are small wrappers around an internal
 *        fully-specialised routine — inliner-friendly.
 *   1.6  Two 64-bit loads / stores for bytes↔state conversion.
 *   2.1  Last round uses T0d..T3d / TD0d..TD3d (4 small tables)
 *        so SubBytes+ShiftRows is one OR per byte position —
 *        no byte-array materialisation, no repacking.
 *   2.2  Three specialised routines (one per AES key size), each
 *        with the round loop fully unrolled.  Dispatched once per
 *        vpaes_set_key via a function pointer in the context.
 *
 * Public-domain.
 */

#include "vpaes.h"
#include <string.h>
#include <stddef.h>       /* size_t */

/* ================================================================== */
/*  Industrial-grade defensive helpers                                  */
/* ================================================================== */

/*
 * secure_zero — best-effort, volatile-pointered memory wipe.
 *
 * Plain memset() is elided by modern optimisers when they can prove the
 * buffer is dead afterwards.  For sensitive material (round-key words)
 * that elision is a security bug.  We force the write through a
 * volatile pointer so the compiler must issue the store.
 *
 * Annex-K `memset_s` (C11) or POSIX `explicit_bzero` are preferred
 * when available; we fall back to the portable volatile loop on
 * conforming freestanding / older hosted implementations.
 */
static void secure_zero(void *p, size_t n)
{
#if defined(__STDC_WANT_LIB_EXT1__)
    memset_s(p, n, 0, n);
#elif defined(__GLIBC__) || defined(__APPLE__) || defined(__OpenBSD__) || \
      defined(__FreeBSD__) || defined(__NetBSD__) || defined(__sun)
    extern void explicit_bzero(void *, size_t);
    explicit_bzero(p, n);
#elif defined(_MSC_VER)
    SecureZeroMemory(p, n);
#elif defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 201112L)
    /* C11 has a memory model that permits us to use memset with a
     * volatile pointer to defeat the optimiser's dead-store elision. */
    volatile uint8_t *vp = (volatile uint8_t *)p;
    while (n--) *vp++ = 0;
#else
    /* C99 fallback: volatile pointer loop.  Note that the standard
     * says the optimiser may still elide stores to objects whose
     * lifetimes have ended, but the volatile qualifier prevents
     * elision for the duration of their lifetime.  This is the best
     * we can do without a libc extension. */
    volatile uint8_t *vp = (volatile uint8_t *)p;
    size_t i = 0;
    while (i < n) { vp[i] = 0; i++; }
#endif
}

/* ================================================================== */
/*  Pre-computed T-tables (in .rodata, no runtime init)                */
/* ================================================================== */

#include "vpaes_tables.inc"

/* S-box (still needed by sub_word / InvMixColumns in key setup) and
 * Rcon.  isbox is NOT used at runtime — last-round decryption uses
 * pre-computed TD0d..TD3d tables.                                    */

static const uint8_t sbox[256] = {
0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
};

static const uint8_t Rcon[15] = {
0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36,0x6c,0xd8,0xab,0x4d
};

/* (The inverse S-box is no longer carried in this translation unit;
 * the runtime decryption path uses the pre-computed TD0d..TD3d tables
 * from vpaes_tables.inc instead.  gen_tables.c, if bundled here, would
 * still need the isbox[] constant — it is provided there.)            */

/* ================================================================== */
/*  GF(2^8) helper (key-setup only)                                    */
/* ================================================================== */

static uint8_t gmul(uint8_t a, uint8_t b)
{
    uint8_t p = 0;
    for (int i = 0; i < 8; i++) {
        if (b & 1) p ^= a;
        uint8_t hi = a & 0x80;
        a <<= 1;
        if (hi) a ^= 0x1b;
        b >>= 1;
    }
    return p;
}

static void inv_mix_columns_columns(uint32_t rk[4])
{
    for (int c = 0; c < 4; c++) {
        uint8_t b0 = (rk[c] >> 24) & 0xff;
        uint8_t b1 = (rk[c] >> 16) & 0xff;
        uint8_t b2 = (rk[c] >>  8) & 0xff;
        uint8_t b3 =  rk[c]        & 0xff;
        rk[c] = ((uint32_t)(gmul(b0,0x0e) ^ gmul(b1,0x0b) ^
                            gmul(b2,0x0d) ^ gmul(b3,0x09)) << 24) |
                ((uint32_t)(gmul(b0,0x09) ^ gmul(b1,0x0e) ^
                            gmul(b2,0x0b) ^ gmul(b3,0x0d)) << 16) |
                ((uint32_t)(gmul(b0,0x0d) ^ gmul(b1,0x09) ^
                            gmul(b2,0x0e) ^ gmul(b3,0x0b)) <<  8) |
                ((uint32_t)(gmul(b0,0x0b) ^ gmul(b1,0x0d) ^
                            gmul(b2,0x09) ^ gmul(b3,0x0e))      );
    }
}

/* ================================================================== */
/*  AES key expansion                                                   */
/* ================================================================== */

static uint32_t sub_word(uint32_t x)
{
    return ((uint32_t)sbox[(x >> 24) & 0xff] << 24) |
           ((uint32_t)sbox[(x >> 16) & 0xff] << 16) |
           ((uint32_t)sbox[(x >>  8) & 0xff] <<  8) |
           ((uint32_t)sbox[(x      ) & 0xff]      );
}

static uint32_t rot_word(uint32_t x)
{
    return ((x << 8) | (x >> 24));
}

static int set_key_impl(uint32_t rk[VPAES_EXP_WORDS], const uint8_t *key, int nk)
{
    int nr, total;
    switch (nk) {
    case 16: nr = 10; total = 176; break;
    case 24: nr = 12; total = 208; break;
    case 32: nr = 14; total = 240; break;
    default: return -1;
    }
    int i = 0;
    while (i < nk / 4) {
        rk[i] = ((uint32_t)key[4*i]   << 24) |
                ((uint32_t)key[4*i+1] << 16) |
                ((uint32_t)key[4*i+2] <<  8) |
                ((uint32_t)key[4*i+3]);
        i++;
    }
    for (; i < total / 4; i++) {
        uint32_t temp = rk[i - 1];
        if ((i % (nk / 4)) == 0)
            temp = sub_word(rot_word(temp)) ^ ((uint32_t)Rcon[i / (nk / 4)] << 24);
        else if (nk > 24 && (i % (nk / 4)) == 4)
            temp = sub_word(temp);
        rk[i] = rk[i - (nk / 4)] ^ temp;
    }
    return nr;
}

/* (No internal typedef needed: vpaes_encrypt_fn / vpaes_decrypt_fn from
 * vpaes.h are the single source of truth for the dispatch pointer types.) */

int vpaes_set_key(vpaes_ctx *ctx, const uint8_t *key, size_t key_len)
{
    if (!ctx || !key) return -1;
    if (key_len != VPAES_KEY_128 && key_len != VPAES_KEY_192 && key_len != VPAES_KEY_256)
        return -1;

    /* M-5: zeroise the previous round-key material before writing new
     * key schedule material.  The round-key arrays are sized for
     * AES-256 (60 words); if the new key is shorter (e.g. AES-128
     * uses 44 words), the TAIL of the arrays would otherwise leak the
     * prior schedule.  Use secure_zero (volatile store loop) so the
     * optimiser cannot elide the wipe.                                    */
    secure_zero(ctx->rk,     sizeof ctx->rk);
    secure_zero(ctx->rk_inv, sizeof ctx->rk_inv);

    int nr = set_key_impl(ctx->rk, key, (int)key_len);
    if (nr < 0) {
        secure_zero(ctx->rk,     sizeof ctx->rk);
        secure_zero(ctx->rk_inv, sizeof ctx->rk_inv);
        return -1;
    }
    ctx->nrounds = nr;

    /* Precompute modified decryption key (rk_inv[r] = InvMC(rk[r])
     * for r in [1, nr-1]). */
    for (int r = 0; r <= nr; r++) {
        ctx->rk_inv[4*r    ] = ctx->rk[4*r    ];
        ctx->rk_inv[4*r + 1] = ctx->rk[4*r + 1];
        ctx->rk_inv[4*r + 2] = ctx->rk[4*r + 2];
        ctx->rk_inv[4*r + 3] = ctx->rk[4*r + 3];
        if (r >= 1 && r <= nr - 1)
            inv_mix_columns_columns(&ctx->rk_inv[4*r]);
    }

    /* Phase 2.2 — bind a specialised routine into the context.
     * Subsequent encrypt/decrypt calls jump through the pointer
     * with zero per-call dispatch overhead.                      */
    extern vpaes_encrypt_fn const enc_dispatch[16];
    extern vpaes_decrypt_fn const dec_dispatch[16];
    ctx->enc_dispatch = enc_dispatch[nr];
    ctx->dec_dispatch = dec_dispatch[nr];
    return 0;
}

/* ================================================================== */
/*  Block <-> state conversion                                         */
/* ================================================================== */

/*
 * Convert 16 input bytes (column-major) into 4 state words.
 *
 *   in[0..3]   -> s[0]   (bytes 0..3 packed MSB-first)
 *   in[4..7]   -> s[1]
 *   in[8..11]  -> s[2]
 *   in[12..15] -> s[3]
 *
 * Phase 1.6 — on little-endian hosts we load all 16 bytes with two
 * 64-bit unaligned loads, byte-swap each 64-bit word (giving a
 * big-endian-style word), then split into two 32-bit column words.
 * x86/ARM/LoongArch all make this 0-cycle for alignment.
 */
static inline uint32_t bswap32(uint32_t v) {
#if defined(__GNUC__) || defined(__clang__)
    return __builtin_bswap32(v);
#else
    return (v >> 24) | ((v >> 8) & 0x0000ff00) |
           ((v << 8) & 0x00ff0000) | (v << 24);
#endif
}

static inline uint64_t bswap64(uint64_t v) {
#if defined(__GNUC__) || defined(__clang__)
    return __builtin_bswap64(v);
#else
    return ((v & 0xFF00000000000000ULL) >> 56) |
           ((v & 0x00FF000000000000ULL) >> 40) |
           ((v & 0x0000FF0000000000ULL) >> 24) |
           ((v & 0x000000FF00000000ULL) >>  8) |
           ((v & 0x00000000FF000000ULL) <<  8) |
           ((v & 0x0000000000FF0000ULL) << 24) |
           ((v & 0x000000000000FF00ULL) << 40) |
           ((v & 0x00000000000000FFULL) << 56);
#endif
}

static inline void bytes_to_state(const uint8_t in[16], uint32_t s[4])
{
#if defined(__BYTE_ORDER__) && (__BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__)
    /* Use memcpy (not pointer-cast) to remain strictly aliasing-clean
     * and to permit the compiler to use whatever load width the target
     * architecture prefers — on x86-64 / LA664 this still lowers to a
     * single 8-byte MOV.                                              */
    uint64_t lo, hi;
    memcpy(&lo, &in[0], 8);
    memcpy(&hi, &in[8], 8);
    /* After a 64-bit bswap the bytes of lo are in MSB-first order:
     * high 32 bits = in[0..3], low 32 bits = in[4..7].  Same for hi.
     * This gives us the column-major word directly.                   */
    lo = bswap64(lo);
    hi = bswap64(hi);
    s[0] = (uint32_t)(lo >> 32);   /* in[0..3] MSB-first */
    s[1] = (uint32_t) lo;          /* in[4..7] MSB-first */
    s[2] = (uint32_t)(hi >> 32);   /* in[8..11] */
    s[3] = (uint32_t) hi;          /* in[12..15] */
#else
    for (int c = 0; c < 4; c++) {
        s[c] = ((uint32_t)in[4*c    ] << 24) |
               ((uint32_t)in[4*c + 1] << 16) |
               ((uint32_t)in[4*c + 2] <<  8) |
               ((uint32_t)in[4*c + 3]      );
    }
#endif
}

static inline void state_to_bytes(const uint32_t s[4], uint8_t out[16])
{
#if defined(__BYTE_ORDER__) && (__BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__)
    /* Pack two column words (each in MSB-first order) into a LE
     * 64-bit value.  We want out[0..3] = bswap32(s[0])  and
     * out[4..7] = bswap32(s[1]); in LE memory, the low 32 bits of
     * the 64-bit value land at out[0..3].  memcpy (not pointer-cast)
     * for strict aliasing safety.                                    */
    uint64_t lo = ((uint64_t)bswap32(s[1]) << 32) | (uint64_t)bswap32(s[0]);
    uint64_t hi = ((uint64_t)bswap32(s[3]) << 32) | (uint64_t)bswap32(s[2]);
    memcpy(&out[0], &lo, 8);
    memcpy(&out[8], &hi, 8);
#else
    for (int c = 0; c < 4; c++) {
        out[4*c    ] = (s[c] >> 24) & 0xff;
        out[4*c + 1] = (s[c] >> 16) & 0xff;
        out[4*c + 2] = (s[c] >>  8) & 0xff;
        out[4*c + 3] = (s[c]      ) & 0xff;
    }
#endif
}

/* ================================================================== */
/*  Round helpers                                                       */
/* ================================================================== */

/*
 * Single encryption round.  Computes all four output columns at
 * once.  For each output column j the four T-table lookups are
 * independent (different memory locations), so the OoO engine can
 * issue them in parallel.  The 4 XORs then sum them into the output.
 */
static inline void enc_round(uint32_t s[4], const uint32_t *rk)
{
    uint32_t s0 = s[0], s1 = s[1], s2 = s[2], s3 = s[3];
    s[0] = Te0[(s0 >> 24) & 0xff] ^ Te1[(s1 >> 16) & 0xff] ^
           Te2[(s2 >>  8) & 0xff] ^ Te3[(s3      ) & 0xff] ^ rk[0];
    s[1] = Te0[(s1 >> 24) & 0xff] ^ Te1[(s2 >> 16) & 0xff] ^
           Te2[(s3 >>  8) & 0xff] ^ Te3[(s0      ) & 0xff] ^ rk[1];
    s[2] = Te0[(s2 >> 24) & 0xff] ^ Te1[(s3 >> 16) & 0xff] ^
           Te2[(s0 >>  8) & 0xff] ^ Te3[(s1      ) & 0xff] ^ rk[2];
    s[3] = Te0[(s3 >> 24) & 0xff] ^ Te1[(s0 >> 16) & 0xff] ^
           Te2[(s1 >>  8) & 0xff] ^ Te3[(s2      ) & 0xff] ^ rk[3];
}

/*
 * Single decryption round (Td tables; rki = rk_inv[r]).
 * Byte access pattern follows the inverse shift-rows permutation.
 */
static inline void dec_round(uint32_t s[4], const uint32_t *rki)
{
    uint32_t s0 = s[0], s1 = s[1], s2 = s[2], s3 = s[3];
    s[0] = Td0[(s0 >> 24) & 0xff] ^ Td1[(s3 >> 16) & 0xff] ^
           Td2[(s2 >>  8) & 0xff] ^ Td3[(s1      ) & 0xff] ^ rki[0];
    s[1] = Td0[(s1 >> 24) & 0xff] ^ Td1[(s0 >> 16) & 0xff] ^
           Td2[(s3 >>  8) & 0xff] ^ Td3[(s2      ) & 0xff] ^ rki[1];
    s[2] = Td0[(s2 >> 24) & 0xff] ^ Td1[(s1 >> 16) & 0xff] ^
           Td2[(s0 >>  8) & 0xff] ^ Td3[(s3      ) & 0xff] ^ rki[2];
    s[3] = Td0[(s3 >> 24) & 0xff] ^ Td1[(s2 >> 16) & 0xff] ^
           Td2[(s1 >>  8) & 0xff] ^ Td3[(s0      ) & 0xff] ^ rki[3];
}

/* Last round: SubBytes + ShiftRows + AddRoundKey (encryption).
 * For output column c, byte r = sbox[input[(c+r)%4] >> (24-8r)].
 * T_kd[i] = sbox[i] << (24-8k) places the result at byte k of a
 * 32-bit word; OR-ing four such lookups covers all four byte slots
 * in one shot, no intermediate byte array, no repack.            */
static inline void enc_last(uint32_t s[4], const uint32_t *rk)
{
    uint32_t s0 = s[0], s1 = s[1], s2 = s[2], s3 = s[3];
    s[0] = (T0d[(s0 >> 24) & 0xff] | T1d[(s1 >> 16) & 0xff] |
            T2d[(s2 >>  8) & 0xff] | T3d[(s3      ) & 0xff]) ^ rk[0];
    s[1] = (T0d[(s1 >> 24) & 0xff] | T1d[(s2 >> 16) & 0xff] |
            T2d[(s3 >>  8) & 0xff] | T3d[(s0      ) & 0xff]) ^ rk[1];
    s[2] = (T0d[(s2 >> 24) & 0xff] | T1d[(s3 >> 16) & 0xff] |
            T2d[(s0 >>  8) & 0xff] | T3d[(s1      ) & 0xff]) ^ rk[2];
    s[3] = (T0d[(s3 >> 24) & 0xff] | T1d[(s0 >> 16) & 0xff] |
            T2d[(s1 >>  8) & 0xff] | T3d[(s2      ) & 0xff]) ^ rk[3];
}

/* Last round decryption helper: InvSubBytes + InvShiftRows only
 * (no AddRoundKey — the AddRoundKey step differs between rounds and
 * is folded into the per-key-size specialised routines below). The
 * prior `dec_last()` was dead code AND carried a wrong XOR (it
 * combined rki and rk with `rki[0] == rk[0]`, so the second XOR
 * cancelled the first; in the last round only the plain AddRoundKey
 * `rk[0]` is needed because InvMixColumns is NOT applied to round
 * 0 or round Nr). */
static inline void dec_last_core(uint32_t s[4])
{
    uint32_t s0 = s[0], s1 = s[1], s2 = s[2], s3 = s[3];
    s[0] = TD0d[(s0 >> 24) & 0xff] | TD1d[(s3 >> 16) & 0xff] |
           TD2d[(s2 >>  8) & 0xff] | TD3d[(s1      ) & 0xff];
    s[1] = TD0d[(s1 >> 24) & 0xff] | TD1d[(s0 >> 16) & 0xff] |
           TD2d[(s3 >>  8) & 0xff] | TD3d[(s2      ) & 0xff];
    s[2] = TD0d[(s2 >> 24) & 0xff] | TD1d[(s1 >> 16) & 0xff] |
           TD2d[(s0 >>  8) & 0xff] | TD3d[(s3      ) & 0xff];
    s[3] = TD0d[(s3 >> 24) & 0xff] | TD1d[(s2 >> 16) & 0xff] |
           TD2d[(s1 >>  8) & 0xff] | TD3d[(s0      ) & 0xff];
}

/* ================================================================== */
/*  Phase 2.2 — specialised routines, one per key size                 */
/* ================================================================== */

/* AES-128: 9 full rounds + 1 last round. */
static void enc_128(uint32_t s[4], const uint32_t *rk)
{
    enc_round(s, rk +  4);   /* round 1 */
    enc_round(s, rk +  8);   /* round 2 */
    enc_round(s, rk + 12);   /* round 3 */
    enc_round(s, rk + 16);   /* round 4 */
    enc_round(s, rk + 20);   /* round 5 */
    enc_round(s, rk + 24);   /* round 6 */
    enc_round(s, rk + 28);   /* round 7 */
    enc_round(s, rk + 32);   /* round 8 */
    enc_round(s, rk + 36);   /* round 9 */
    enc_last(s,  rk + 40);   /* last round  */
}

/* AES-192: 11 full rounds + 1 last round. */
static void enc_192(uint32_t s[4], const uint32_t *rk)
{
    enc_round(s, rk +  4);   enc_round(s, rk +  8);
    enc_round(s, rk + 12);   enc_round(s, rk + 16);
    enc_round(s, rk + 20);   enc_round(s, rk + 24);
    enc_round(s, rk + 28);   enc_round(s, rk + 32);
    enc_round(s, rk + 36);   enc_round(s, rk + 40);
    enc_round(s, rk + 44);
    enc_last(s,  rk + 48);
}

/* AES-256: 13 full rounds + 1 last round. */
static void enc_256(uint32_t s[4], const uint32_t *rk)
{
    enc_round(s, rk +  4);   enc_round(s, rk +  8);
    enc_round(s, rk + 12);   enc_round(s, rk + 16);
    enc_round(s, rk + 20);   enc_round(s, rk + 24);
    enc_round(s, rk + 28);   enc_round(s, rk + 32);
    enc_round(s, rk + 36);   enc_round(s, rk + 40);
    enc_round(s, rk + 44);   enc_round(s, rk + 48);
    enc_round(s, rk + 52);
    enc_last(s,  rk + 56);
}

/* AES-128 decrypt: 9 inverse rounds + final round. */
static void dec_128(uint32_t s[4], const uint32_t *rk,
                    const uint32_t *rki)
{
    /* Use rki[rounds-1 .. 1] in order.  rk is ctx->rk; we need
     * rk[0..3] for the final AddRoundKey.                         */
    dec_round(s, rki + 36);
    dec_round(s, rki + 32);
    dec_round(s, rki + 28);
    dec_round(s, rki + 24);
    dec_round(s, rki + 20);
    dec_round(s, rki + 16);
    dec_round(s, rki + 12);
    dec_round(s, rki +  8);
    dec_round(s, rki +  4);
    /* Final round: InvSubBytes + InvShiftRows + AddRoundKey(rk[0..3])
     * (no InvMixColumns).                                         */
    dec_last_core(s);
    s[0] ^= rk[0]; s[1] ^= rk[1]; s[2] ^= rk[2]; s[3] ^= rk[3];
}

/* AES-192 decrypt. */
static void dec_192(uint32_t s[4], const uint32_t *rk,
                    const uint32_t *rki)
{
    dec_round(s, rki + 44);
    dec_round(s, rki + 40);
    dec_round(s, rki + 36);
    dec_round(s, rki + 32);
    dec_round(s, rki + 28);
    dec_round(s, rki + 24);
    dec_round(s, rki + 20);
    dec_round(s, rki + 16);
    dec_round(s, rki + 12);
    dec_round(s, rki +  8);
    dec_round(s, rki +  4);
    dec_last_core(s);
    s[0] ^= rk[0]; s[1] ^= rk[1]; s[2] ^= rk[2]; s[3] ^= rk[3];
}

/* AES-256 decrypt. */
static void dec_256(uint32_t s[4], const uint32_t *rk,
                    const uint32_t *rki)
{
    dec_round(s, rki + 52);
    dec_round(s, rki + 48);
    dec_round(s, rki + 44);
    dec_round(s, rki + 40);
    dec_round(s, rki + 36);
    dec_round(s, rki + 32);
    dec_round(s, rki + 28);
    dec_round(s, rki + 24);
    dec_round(s, rki + 20);
    dec_round(s, rki + 16);
    dec_round(s, rki + 12);
    dec_round(s, rki +  8);
    dec_round(s, rki +  4);
    dec_last_core(s);
    s[0] ^= rk[0]; s[1] ^= rk[1]; s[2] ^= rk[2]; s[3] ^= rk[3];
}

/* The dispatch tables — sparse (nrounds in {10, 12, 14}). */
vpaes_encrypt_fn const enc_dispatch[16] = {
    [10] = enc_128,
    [12] = enc_192,
    [14] = enc_256,
};

vpaes_decrypt_fn const dec_dispatch[16] = {
    [10] = dec_128,
    [12] = dec_192,
    [14] = dec_256,
};

/* ================================================================== */
/*  Public API                                                          */
/* ================================================================== */

void vpaes_encrypt_block(const vpaes_ctx *ctx,
                         const uint8_t in[VPAES_BLOCKLEN],
                         uint8_t       out[VPAES_BLOCKLEN])
{
    uint32_t s[4];
    bytes_to_state(in, s);
    s[0] ^= ctx->rk[0]; s[1] ^= ctx->rk[1];
    s[2] ^= ctx->rk[2]; s[3] ^= ctx->rk[3];
    ctx->enc_dispatch(s, ctx->rk);
    state_to_bytes(s, out);
}

void vpaes_decrypt_block(const vpaes_ctx *ctx,
                         const uint8_t in[VPAES_BLOCKLEN],
                         uint8_t       out[VPAES_BLOCKLEN])
{
    uint32_t s[4];
    const uint32_t *rk = ctx->rk + 4 * ctx->nrounds;
    bytes_to_state(in, s);
    s[0] ^= rk[0]; s[1] ^= rk[1];
    s[2] ^= rk[2]; s[3] ^= rk[3];
    ctx->dec_dispatch(s, ctx->rk, ctx->rk_inv);
    state_to_bytes(s, out);
}

/* ================================================================== */
/*  ECB / CBC / CTR                                                    */
/* ================================================================== */

void vpaes_ecb_encrypt(const vpaes_ctx *ctx,
                       const uint8_t *in, uint8_t *out, size_t len)
{
    while (len >= VPAES_BLOCKLEN) {
        vpaes_encrypt_block(ctx, in, out);
        in  += VPAES_BLOCKLEN;
        out += VPAES_BLOCKLEN;
        len -= VPAES_BLOCKLEN;
    }
}

void vpaes_ecb_decrypt(const vpaes_ctx *ctx,
                       const uint8_t *in, uint8_t *out, size_t len)
{
    while (len >= VPAES_BLOCKLEN) {
        vpaes_decrypt_block(ctx, in, out);
        in  += VPAES_BLOCKLEN;
        out += VPAES_BLOCKLEN;
        len -= VPAES_BLOCKLEN;
    }
}

/* Phase 1.3 — in-place CBC.                                            */
/* M-4 fix: route all loads/stores through memcpy to a stack buffer so */
/* the loop is aliasing-clean and safe for arbitrary (in, out) pointer */
/* pairs (fully aliased or fully disjoint; partial overlap remains     */
/* undefined per vpaes.h).                                              */
void vpaes_cbc_encrypt(const vpaes_ctx *ctx,
                       const uint8_t iv[VPAES_BLOCKLEN],
                       const uint8_t *in, uint8_t *out, size_t len)
{
    uint8_t prev[VPAES_BLOCKLEN];
    memcpy(prev, iv, VPAES_BLOCKLEN);
    while (len >= VPAES_BLOCKLEN) {
        /* Copy plaintext + prev through stack; XOR using local
         * uint64_t (allowed — local variable, not aliased); emit
         * ciphertext via memcpy back to `out`.  No strict-aliasing
         * violation: the uint64_t variables are local and outlive
         * the subsequent memcpy-of-the-pointer. */
        uint64_t pt_lo, pt_hi, pv_lo, pv_hi;
        uint8_t out_buf[VPAES_BLOCKLEN];
        memcpy(&pt_lo, &in[0],  sizeof(uint64_t));
        memcpy(&pt_hi, &in[8],  sizeof(uint64_t));
        memcpy(&pv_lo, &prev[0], sizeof(uint64_t));
        memcpy(&pv_hi, &prev[8], sizeof(uint64_t));
        pt_lo ^= pv_lo;
        pt_hi ^= pv_hi;
        memcpy(&out_buf[0], &pt_lo, sizeof(uint64_t));
        memcpy(&out_buf[8], &pt_hi, sizeof(uint64_t));
        /* out_buf now holds (plaintext XOR prev); encrypt through a
         * scratch write of the full 16 bytes to `out`, leaving any
         * partial overlap impossible. */
        memcpy(out, out_buf, VPAES_BLOCKLEN);
        vpaes_encrypt_block(ctx, out, out);
        memcpy(prev, out, VPAES_BLOCKLEN);
        in  += VPAES_BLOCKLEN;
        out += VPAES_BLOCKLEN;
        len -= VPAES_BLOCKLEN;
    }
}

/* M-7 fix: when in != out the propagated-ciphertext copy is redundant; */
/* the unaliased input `in` already supplies it.  In-place (in == out) */
/* still pays the copy cost (mandatory).  The XOR-write to `out` flows */
/* through a private 16-byte buffer so the function is safe for the     */
/* (in, out) pointer relationships documented in vpaes.h.              */
void vpaes_cbc_decrypt(const vpaes_ctx *ctx,
                       const uint8_t iv[VPAES_BLOCKLEN],
                       const uint8_t *in, uint8_t *out, size_t len)
{
    uint8_t prev[VPAES_BLOCKLEN];
    uint8_t tmp [VPAES_BLOCKLEN];   /* decrypt target                    */
    uint8_t curr[VPAES_BLOCKLEN];   /* only used when in == out          */
    memcpy(prev, iv, VPAES_BLOCKLEN);
    while (len >= VPAES_BLOCKLEN) {
        /* Save ciphertext for the next iteration's `prev`.  Only when
         * in == out is the dedicated copy required (otherwise `in`
         * still points at the freshly-written ciphertext). */
        const uint8_t *next_prev;
        if (in == out) {
            memcpy(curr, in, VPAES_BLOCKLEN);
            next_prev = curr;
        } else {
            next_prev = in;
        }
        vpaes_decrypt_block(ctx, in, tmp);
        /* Compose (tmp XOR prev) into a stack buffer; emit to `out`
         * via memcpy.  Mirrors the M-4 fix in vpaes_cbc_encrypt. */
        uint64_t t_lo, t_hi, p_lo, p_hi;
        memcpy(&t_lo, &tmp[0],  sizeof(uint64_t));
        memcpy(&t_hi, &tmp[8],  sizeof(uint64_t));
        memcpy(&p_lo, &prev[0], sizeof(uint64_t));
        memcpy(&p_hi, &prev[8], sizeof(uint64_t));
        t_lo ^= p_lo;
        t_hi ^= p_hi;
        memcpy(&out[0], &t_lo, sizeof(uint64_t));
        memcpy(&out[8], &t_hi, sizeof(uint64_t));
        memcpy(prev, next_prev, VPAES_BLOCKLEN);
        in  += VPAES_BLOCKLEN;
        out += VPAES_BLOCKLEN;
        len -= VPAES_BLOCKLEN;
    }
}

/* Phase 1.4 — CTR with 32-bit big-endian counter increment.            */
/* M-3 fix: reject inputs that would wrap the 32-bit counter (RFC 3686  */
/* requires < 2^32 blocks per IV).  M-4 mirror: the byte-by-byte XOR    */
/* loop is replaced with a private stack buffer to make the routine     */
/* safe for partial overlap between `in` and `out`.                     */
void vpaes_ctr_xcrypt(const vpaes_ctx *ctx,
                      const uint8_t iv[VPAES_BLOCKLEN],
                      const uint8_t *in, uint8_t *out, size_t len)
{
    /* M-3: enforce < 2^32 blocks per IV; refuse (silent no-op) inputs
     * that would wrap the BE counter.  This costs 1 compare + branch
     * per call, and prevents the catastrophic keystream-reuse case.
     * Callers with > 64 GiB streams must chunk and bump the upper 96
     * bits of the IV manually.                                          */
    if (len > (size_t)0xFFFFFFFFULL * VPAES_BLOCKLEN) {
        return;
    }

    uint8_t ctr[VPAES_BLOCKLEN];
    uint8_t ks [VPAES_BLOCKLEN];
    memcpy(ctr, iv, VPAES_BLOCKLEN);
    while (len > 0) {
        vpaes_encrypt_block(ctx, ctr, ks);
        size_t n = len < VPAES_BLOCKLEN ? len : VPAES_BLOCKLEN;

        /* M-4: route the XOR through a private stack buffer so the
         * write to `out` never aliases with the read of `in`.  This
         * makes CTR safe for arbitrary (in, out) relationships.     */
        uint8_t out_buf[VPAES_BLOCKLEN];
        if (n == VPAES_BLOCKLEN) {
            uint64_t ks0, ks1, in0, in1;
            memcpy(&ks0, &ks[0], sizeof(uint64_t));
            memcpy(&ks1, &ks[8], sizeof(uint64_t));
            memcpy(&in0, &in[0], sizeof(uint64_t));
            memcpy(&in1, &in[8], sizeof(uint64_t));
            ks0 ^= in0;
            ks1 ^= in1;
            memcpy(&out_buf[0], &ks0, sizeof(uint64_t));
            memcpy(&out_buf[8], &ks1, sizeof(uint64_t));
        } else {
            /* Partial-block tail: byte-by-byte XOR via the stack buf. */
            for (size_t i = 0; i < n; i++) out_buf[i] = (uint8_t)(in[i] ^ ks[i]);
        }
        memcpy(out, out_buf, n);
        in  += n;
        out += n;
        len -= n;
        /* Only advance the counter if there is at least one more block
         * to process.  RFC 3686 says the upper 96 bits of the IV are
         * fixed and the lower 32 bits are the counter; after processing
         * K blocks the counter must equal CK + K, so we need exactly
         * K increments for K blocks.                                    */
        if (len > 0) {
            uint32_t c = ((uint32_t)ctr[12] << 24) |
                         ((uint32_t)ctr[13] << 16) |
                         ((uint32_t)ctr[14] <<  8) |
                         ((uint32_t)ctr[15]      );
            c++;
            ctr[12] = (uint8_t)(c >> 24);
            ctr[13] = (uint8_t)(c >> 16);
            ctr[14] = (uint8_t)(c >>  8);
            ctr[15] = (uint8_t)(c      );
        }
    }
}