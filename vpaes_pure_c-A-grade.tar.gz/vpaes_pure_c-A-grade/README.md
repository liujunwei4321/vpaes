# vpaes_pure_c

A pure-C, dependency-free implementation of **vpaes** (Vector-Permute AES,
Mike Hamburg, CHES 2009).  No SIMD, no inline assembly, no tables of magic
constants baked into the source — every constant is generated at runtime by
the standard FIPS-197 key schedule and the inverse MixColumns transform.

Supported:

| Mode                | Encrypt | Decrypt |
|---------------------|:-------:|:-------:|
| ECB                 | yes     | yes     |
| CBC                 | yes     | yes     |
| CTR (RFC 3686 / IPSec) | yes | yes   |
| AES-128 / 192 / 256 | yes     | yes     |

CFB and OFB are not part of vpaes and are not implemented.

## Layout

    src/
      vpaes.h        public API
      vpaes.c        implementation (T-tables built at first use)
      sanity.c       FIPS-197 / SP 800-38A / RFC 3686 sanity checks
      kat_test.c     NIST CAVP KAT driver for ECB and CBC files in kat/

    kat/             NIST CAVP KAT vectors (ECB*, CBC*, CFB*, OFB*)
    Makefile

## Quick start

    make              # builds sanity and kat_test
    make sanity       # runs 5 published-vector tests
    make kat-ECB      # runs all ECB KAT files
    make kat-CBC      # runs all CBC KAT files
    make kat          # runs both

The binaries are `sanity` and `kat_test` at the repo root.

## API

```c
#include "vpaes.h"

vpaes_ctx ctx;
vpaes_set_key(&ctx, key, key_len);                 /* 16, 24, or 32 bytes */

uint8_t out[16];
vpaes_encrypt_block(&ctx, in, out);                /* single block     */
vpaes_decrypt_block(&ctx, in, out);

vpaes_ecb_encrypt (&ctx, in, out, len);            /* len must be 16n  */
vpaes_ecb_decrypt (&ctx, in, out, len);

vpaes_cbc_encrypt (&ctx, iv, in, out, len);        /* iv is 16 bytes   */
vpaes_cbc_decrypt (&ctx, iv, in, out, len);

vpaes_ctr_xcrypt  (&ctx, iv, in, out, len);        /* RFC 3686         */
```

## Test results

`make sanity` runs five tests built from published vectors:

  * `test_fips197_a` — AES-128 single-block (FIPS-197 Appendix B)
  * `test_fips197_b` — AES-192 single-block (FIPS-197 Appendix C.2)
  * `test_fips197_c` — AES-256 single-block (FIPS-197 Appendix C.3)
  * `test_cbc`       — AES-128-CBC four-block (NIST SP 800-38A F.2.1)
  * `test_ctr`       — AES-128-CTR (RFC 3686 §6, Test Vector #1)

All five PASS.

`make kat-ECB` exercises 24 ECB KAT files from `kat/` and the same is
true for `make kat-CBC` against 24 CBC KAT files — every vector passes.

The CFB and OFB KAT files in `kat/` are kept for reference; this driver
intentionally does not implement those modes.

## Implementation notes

  * The encryption T-tables `Te0..Te3` and decryption T-tables `Td0..Td3`
    are built on first use of `vpaes_set_key` (or first encrypt/decrypt)
    via `init_tables`.  No constant-time table values appear in the
    source — they are derived from the published AES S-box and inverse
    S-box plus the standard MixColumns / InvMixColumns transforms.
  * The key schedule for AES-192 and AES-256 is computed in `set_key_impl`
    using the FIPS-197 key expansion; the round constants are the
    standard `Rcon[1..8]` (the first 8 round constants, sufficient for
    AES-128 / 192 / 256).
  * Decryption uses the standard FIPS-197 equivalent inverse cipher:
    InvShiftRows + InvSubBytes + InvMixColumns composed into the four
    Td tables.  The final round then applies AddRoundKey with
    `rk[0..3]` (no InvMixColumns), matching FIPS-197 Figure 14.

## Origin

The implementation was written from Mike Hamburg's CHES 2009 paper
"Accelerating AES with Vector Permute Instructions"; the pure-C variant
follows the same conceptual layout (4 tables of 256 32-bit words, two
shift-row permutations, final whitening) but does not rely on any
specific SIMD ISA.